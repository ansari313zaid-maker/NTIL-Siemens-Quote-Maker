package com.ntil.quotationmaker.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.text.PDFTextStripper
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.Locale
import java.util.regex.Pattern

/** Offline Siemens master. Seeded from the July 2026 Siemens price-list PDF data and can be updated by importing a new PDF. */
data class SiemensProduct(
    val code: String,
    val price: Double,
    val priceLabel: String,
    val page: Int,
    val description: String = "",
    val category: String = "Other Siemens Products"
) {
    val normalized: String get() = code.uppercase(Locale.US).filter { it.isLetterOrDigit() }
}

data class ImportResult(val updated: Int, val added: Int, val skipped: Int, val message: String)

class SiemensPriceRepository private constructor(private val context: Context) {
    private val store = File(context.filesDir, "siemens_master.tsv")
    private var products: MutableList<SiemensProduct> = mutableListOf()

    init { reload() }

    @Synchronized fun reload() {
        if (!store.exists()) seedFromAsset()
        products = loadFile(store).toMutableList()
        if (products.isEmpty()) seedFromAsset()
    }

    fun all(): List<SiemensProduct> = products.toList()
    fun categories(): List<String> = products.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()

    fun search(query: String, category: String? = null, limit: Int = 12): List<SiemensProduct> {
        val q = query.uppercase(Locale.US).trim()
        val n = q.filter { it.isLetterOrDigit() }
        return products.asSequence()
            .filter { category.isNullOrBlank() || it.category == category }
            .filter { q.isBlank() || it.code.uppercase(Locale.US).contains(q) || it.normalized.contains(n) || it.description.uppercase(Locale.US).contains(q) }
            .sortedWith(compareBy<SiemensProduct> { if (it.code.equals(q, true)) 0 else if (it.normalized == n) 1 else 2 }.thenBy { it.code })
            .take(limit).toList()
    }

    fun exactOrNormalized(query: String): SiemensProduct? {
        val q = query.uppercase(Locale.US).trim(); val n = q.filter { it.isLetterOrDigit() }
        return products.firstOrNull { it.code.equals(q, true) } ?: products.firstOrNull { it.normalized == n }
    }

    suspend fun importPdf(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val input = context.contentResolver.openInputStream(uri) ?: return@withContext ImportResult(0,0,0,"Could not open PDF")
        input.use { stream ->
            PDDocument.load(stream).use { doc ->
                val text = PDFTextStripper().getText(doc)
                val parsed = parsePdf(text)
                if (parsed.isEmpty()) return@withContext ImportResult(0,0,0,"No Siemens product codes/prices found. Old master kept safe.")
                val byCode = products.associateBy { it.code.uppercase(Locale.US) }.toMutableMap()
                var updated = 0; var added = 0
                parsed.forEach { p ->
                    val key = p.code.uppercase(Locale.US)
                    val old = byCode[key]
                    if (old == null) { byCode[key] = p; added++ }
                    else {
                        byCode[key] = p.copy(
                            description = p.description.ifBlank { old.description },
                            category = if (p.category == "Other Siemens Products") old.category else p.category
                        )
                        updated++
                    }
                }
                val merged = byCode.values.sortedBy { it.code }
                saveFile(merged)
                products = merged.toMutableList()
                ImportResult(updated, added, parsed.count { it.code.isBlank() }, "Price Master updated successfully")
            }
        }
    }

    private fun parsePdf(text: String): List<SiemensProduct> {
        val result = linkedMapOf<String, SiemensProduct>()
        val pages = text.split('\u000c')
        val codePattern = Pattern.compile("(?<![A-Z0-9])([0-9][A-Z0-9]{1,}(?:-[A-Z0-9.]{1,}){0,6})(?![A-Z0-9])", Pattern.CASE_INSENSITIVE)
        val pricePattern = Pattern.compile("(?<![0-9])([0-9]{1,3}(?:,[0-9]{2,3})*(?:\\.[0-9]{1,2})?)(?:\\.-|\\.00)?(?![0-9])")
        pages.forEachIndexed { pageIndex, page ->
            val lines = page.lines().map { it.replace(Regex("\\s+"), " ").trim() }.filter { it.isNotBlank() }
            lines.forEachIndexed { idx, line ->
                val m = codePattern.matcher(line)
                while (m.find()) {
                    val code = m.group(1) ?: continue
                    if (!code.any { it.isLetter() } || !code.any { it.isDigit() }) continue
                    var price = 0.0
                    val window = (idx..minOf(lines.lastIndex, idx + 2)).map { lines[it] }
                    outer@ for (w in window) {
                        val pm = pricePattern.matcher(w)
                        while (pm.find()) {
                            val raw = pm.group(1)?.replace(",", "") ?: continue
                            val v = raw.toDoubleOrNull() ?: continue
                            if (v > 0) { price = v; break@outer }
                        }
                    }
                    if (price <= 0) continue
                    val desc = line.substring(0, m.start()).trim(' ', '-', '–', '—', '|')
                    val category = inferCategory(code)
                    result[code.uppercase(Locale.US)] = SiemensProduct(code, price, if (line.contains("MRP", true)) "MRP" else "LP", pageIndex + 1, desc, category)
                }
            }
        }
        return result.values.toList()
    }

    private fun inferCategory(code: String): String {
        val c = code.uppercase(Locale.US)
        val map = listOf(
            "3RT" to "Contactors", "3RH" to "Contactor Relays", "3RU" to "Thermal Overload Relays", "3RB" to "Electronic Overload Relays", "3RV" to "Motor Protection",
            "3RW" to "Soft Starters", "3SK" to "Safety Relays", "3TK" to "Safety Relays", "3VA" to "MCCB", "3WL" to "ACB", "3VL" to "MCCB",
            "5SL" to "MCB", "5SY" to "MCB", "5SP" to "MCB", "5SV" to "RCCB / RCBO", "5SU" to "RCBO", "5ST" to "Accessories", "5SM" to "RC Units",
            "5TT" to "Modular Devices", "5TG" to "Wiring Devices", "5TA" to "Wiring Devices", "5TC" to "Wiring Devices", "5TE" to "Wiring Devices", "5WG" to "Wiring Devices",
            "6ES" to "SIMATIC / PLC", "6GK" to "Industrial Communication", "6AV" to "HMI", "6EP" to "Power Supplies", "6SL" to "Drives", "6RA" to "Drives", "6SE" to "Drives",
            "8GB" to "Distribution Boards", "8GK" to "Distribution Boards", "7KT" to "Energy Meters", "7KN" to "Energy Management", "7LQ" to "Modular Devices", "7KM" to "Energy Meters",
            "1FK" to "Motors", "1LE" to "Motors", "1LA" to "Motors", "1PH" to "Motors", "1PV" to "Motors", "1FW" to "Motors"
        )
        return map.firstOrNull { c.startsWith(it.first) }?.second ?: "Other Siemens Products"
    }

    private fun seedFromAsset() {
        context.assets.open("siemens_product_master.tsv").use { input -> store.outputStream().use { out -> input.copyTo(out) } }
    }

    private fun loadFile(file: File): List<SiemensProduct> {
        if (!file.exists()) return emptyList()
        val list = mutableListOf<SiemensProduct>()
        BufferedReader(InputStreamReader(file.inputStream(), Charsets.UTF_8)).useLines { lines ->
            lines.drop(1).forEach { line ->
                val p = line.split('\t')
                if (p.size >= 4) list += SiemensProduct(p[0], p[1].toDoubleOrNull() ?: 0.0, p[2], p[3].toIntOrNull() ?: 0, p.getOrElse(4) { "" }, p.getOrElse(5) { "Other Siemens Products" })
            }
        }
        return list
    }

    private fun saveFile(list: List<SiemensProduct>) {
        store.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("code\tprice\tpriceLabel\tpage\tdescription\tcategory\n")
            list.forEach { p -> w.write(listOf(p.code,p.price.toString(),p.priceLabel,p.page.toString(),p.description.replace('\t',' '),p.category.replace('\t',' ')).joinToString("\t") + "\n") }
        }
    }

    companion object {
        @Volatile private var INSTANCE: SiemensPriceRepository? = null
        fun get(context: Context): SiemensPriceRepository = INSTANCE ?: synchronized(this) { INSTANCE ?: SiemensPriceRepository(context.applicationContext).also { INSTANCE = it } }
    }
}
