package com.ntil.quotationmaker.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.util.Locale

object PdfExporter {
    private val blue=Color.rgb(17,91,145); private val dark=Color.rgb(35,45,55); private val light=Color.rgb(235,243,249)
    private fun money(v:Double)="₹"+String.format(Locale.US,"%,.2f",v)
    private fun wrap(text:String,paint:Paint,max:Float):List<String>{ val out=mutableListOf<String>(); var cur=""; text.split(Regex("\\s+")).forEach{w->val t=if(cur.isBlank())w else "$cur $w";if(paint.measureText(t)>max&&cur.isNotBlank()){out+=cur;cur=w}else cur=t};if(cur.isNotBlank())out+=cur;return out}
    fun create(context:Context,q:QuotationDraft):File{
        val dir=File(context.cacheDir,"exports").apply{mkdirs()};val name=q.quotationNo.replace("/","_").ifBlank{"quotation"};val file=File(dir,"$name.pdf")
        val doc=PdfDocument();var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());var c=page.canvas;var y=34f
        val p=Paint(Paint.ANTI_ALIAS_FLAG);p.typeface=Typeface.DEFAULT;p.color=dark;p.textSize=8f
        fun newPage(){
            doc.finishPage(page)
            pageNo++
            page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create())
            c=page.canvas
            y=34f
            p.color=blue
            c.drawRect(0f,0f,595f,76f,p)
            p.color=Color.WHITE
            p.textSize=16f
            p.typeface=Typeface.DEFAULT_BOLD
            c.drawText("Network Techlab India Limited",84f,28f,p)
            p.textSize=9f
            p.typeface=Typeface.DEFAULT
            c.drawText("Plot No. 142, Rd Number 23, MIDC, Wagle Industrial Estate",84f,43f,p)
            c.drawText("Thane, Maharashtra – 400604  |  zaid@netlabindia.com  |  7843852347",84f,57f,p)
            runCatching{BitmapFactory.decodeResource(context.resources,context.resources.getIdentifier("ntil_logo","drawable",context.packageName))?.let{b->c.drawBitmap(b,null,RectF(18f,10f,72f,66f),p)}}
            p.color=blue
            p.textSize=18f
            p.typeface=Typeface.DEFAULT_BOLD
            c.drawText("QUOTATION",235f,101f,p)
            y=118f
        }
        fun drawHeader(){p.color=blue;c.drawRect(0f,0f,595f,76f,p);p.color=Color.WHITE;p.textSize=16f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("Network Techlab India Limited",84f,28f,p);p.textSize=9f;p.typeface=Typeface.DEFAULT;c.drawText("Plot No. 142, Rd Number 23, MIDC, Wagle Industrial Estate, Thane West",84f,43f,p);c.drawText("Thane, Maharashtra – 400604  |  zaid@netlabindia.com  |  7843852347",84f,57f,p);runCatching{BitmapFactory.decodeResource(context.resources,context.resources.getIdentifier("ntil_logo","drawable",context.packageName))?.let{b->c.drawBitmap(b,null,RectF(18f,10f,72f,66f),p)}};p.color=blue;p.textSize=18f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("QUOTATION",235f,101f,p);y=118f}
        fun box(x:Float,w:Float,title:String,rows:List<Pair<String,String>>){p.color=blue;c.drawRect(x,y,x+w,y+18,p);p.color=Color.WHITE;p.textSize=8f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(title,x+6,y+12,p);var yy=y+32;p.color=dark;p.typeface=Typeface.DEFAULT;p.textSize=7.5f;rows.forEach{(a,b)->c.drawText("$a:",x+6,yy,p);c.drawText(b.ifBlank{"—"},x+92,yy,p);yy+=13};p.style=Paint.Style.STROKE;p.color=blue;c.drawRect(x,y,x+w,yy+4,p);p.style=Paint.Style.FILL;y=maxOf(y,yy+12)}
        drawHeader();box(24f,266f,"CUSTOMER DETAILS",listOf("Customer" to q.customer,"Location" to q.location,"Contact Person" to q.contactPerson,"Phone" to q.phone,"Email" to q.email));val y2=y-74; // reset second box to same band
        val savedY=y;y=y2;box(305f,266f,"QUOTATION DETAILS",listOf("Quotation No." to q.quotationNo,"Quotation Date" to q.date,"Enquiry Date" to q.enquiryDate,"Sales Person" to q.salesPerson));y=maxOf(savedY,y)
        p.color=dark;p.textSize=8f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("Subject",30f,y+2,p);p.typeface=Typeface.DEFAULT;c.drawText(q.subject,80f,y+2,p);y+=18
        p.color=blue;c.drawRect(24f,y,571f,y+18,p);p.color=Color.WHITE;p.textSize=8.5f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("BOQ / COMMERCIAL OFFER",30f,y+12,p);y+=26
        val widths=floatArrayOf(20f,70f,180f,32f,34f,58f,42f,60f,55f,44f);val heads=listOf("Sr","Product Code","Material Description","Qty","Unit","LP/MRP","Disc.","Net Rate","Amount","Stock");val xs=FloatArray(10);xs[0]=24f;for(i in 1 until 10)xs[i]=xs[i-1]+widths[i-1];p.color=light;c.drawRect(24f,y-10,571f,y+10,p);p.color=dark;p.textSize=6.5f;p.typeface=Typeface.DEFAULT_BOLD;heads.forEachIndexed{i,h->c.drawText(h,xs[i]+2,y+4,p)};y+=20;p.typeface=Typeface.DEFAULT
        val basic=q.items.sumOf{it.sellingAmount};q.items.forEach{item->
            val desc=if(item.fullDescription.isBlank()) item.productCode else item.fullDescription;val lines=wrap(desc,p,176f);val h=maxOf(22f,lines.size*9f+8f);if(y+h>770f)newPage();p.color=dark;p.textSize=6.5f;c.drawText(item.srNo,xs[0]+2,y,p);c.drawText(item.productCode.take(16),xs[1]+2,y,p);lines.forEachIndexed{i,l->c.drawText(l,xs[2]+2,y+i*9,p)};c.drawText(String.format(Locale.US,"%.2f",item.qty),xs[3]+2,y,p);c.drawText(item.unit.take(6),xs[4]+2,y,p);if(q.showLpMrp)c.drawText(money(item.officialPrice),xs[5]+2,y,p);if(q.showSaleDiscount)c.drawText(if(item.saleDiscount==0.0)"" else String.format(Locale.US,"%.2f%%",item.saleDiscount),xs[6]+2,y,p);if(q.showNetRate)c.drawText(money(item.sellingRate),xs[7]+2,y,p);if(q.showAmount)c.drawText(money(item.sellingAmount),xs[8]+2,y,p);c.drawText(item.stockStatus.take(10),xs[9]+2,y,p);p.color=Color.LTGRAY;c.drawLine(24f,y+h-5,571f,y+h-5,p);y+=h}
        p.color=dark;p.typeface=Typeface.DEFAULT_BOLD;p.textSize=8f;c.drawText("Basic Quotation Value",390f,y+4,p);c.drawText(money(basic),500f,y+4,p);y+=18
        c.drawText("Taxable Value",390f,y+4,p);c.drawText(money(basic),500f,y+4,p);y+=16;val gst=basic*q.gstPercent/100.0;c.drawText("GST @ ${q.gstPercent}%",390f,y+4,p);c.drawText(money(gst),500f,y+4,p);y+=18;p.color=blue;c.drawRect(380f,y-4,571f,y+22,p);p.color=Color.WHITE;c.drawText("GRAND TOTAL",390f,y+11,p);c.drawText(money(basic+gst),500f,y+11,p);y+=34
        fun section(title:String){p.color=blue;c.drawRect(24f,y,571f,y+18,p);p.color=Color.WHITE;p.textSize=8.5f;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(title,30f,y+12,p);y+=27;p.color=dark;p.typeface=Typeface.DEFAULT;p.textSize=7.5f}
        section("COMMERCIAL TERMS");listOf("1. Payment Terms: ${q.paymentTerms}","2. GST: ${q.gstPercent}%","3. Freight Charges: ${q.freightCharges.ifBlank{"—"}}").forEach{c.drawText(it,30f,y,p);y+=13}
        section("ADDITIONAL TERMS");listOf("1. Price Validity: ${q.priceValidity}","2. Warranty: ${q.warranty}","3. Estimated Delivery: ${q.estimatedDelivery}","4. ${q.additionalTermOrder}","5. ${q.additionalTermLabour}").forEach{t->wrap(t,p,535f).forEach{line->if(y>790f)newPage();c.drawText(line,30f,y,p);y+=11};y+=2}
        section("BANK DETAILS");listOf("Bank: ICICI Bank Ltd.","Branch: Shop No. 9, Ground Floor, Jinja Co-Op Society, Opp. Damani Estate, Naupada, Teen Hath Naka – 400604","Branch Name: Thane – Teen Hath Naka Branch","Account No.: 100051000002","IFSC: ICIC00001000","SWIFT: ICICINBBCTS","Account Type: Current Account").forEach{wrap(it,p,535f).forEach{line->c.drawText(line,30f,y,p);y+=11}}
y+=12;p.typeface=Typeface.DEFAULT_BOLD;c.drawText("For Network Techlab India Limited",420f,y,p);y+=24;p.textSize=18f;p.typeface=Typeface.create("cursive",Typeface.ITALIC);c.drawText("Zaid",475f,y,p);y+=12;p.textSize=7.5f;p.typeface=Typeface.DEFAULT;c.drawText("Authorized Signatory",458f,y,p)
        p.style=Paint.Style.STROKE;p.color=blue;c.drawRect(12f,12f,583f,830f,p);p.style=Paint.Style.FILL;doc.finishPage(page);file.outputStream().use{doc.writeTo(it)};doc.close();return file
    }
}
