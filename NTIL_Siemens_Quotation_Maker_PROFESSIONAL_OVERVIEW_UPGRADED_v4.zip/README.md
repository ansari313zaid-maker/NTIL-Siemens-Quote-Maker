# NTIL Siemens Quotation Maker – Professional UI Fixed

Latest UI/PDF update:
- Purchase Discount remains available for internal costing in the app.
- Purchase Rate, Purchase Amount, Purchase Discount and Margin are never printed in customer-facing PDF.
- Professional quotation workspace header and cleaner item cards.
- Compact Qty/Unit fields.
- Product search remains visible with results below it.
- Stock Status remains part of the customer-facing BOQ table.
