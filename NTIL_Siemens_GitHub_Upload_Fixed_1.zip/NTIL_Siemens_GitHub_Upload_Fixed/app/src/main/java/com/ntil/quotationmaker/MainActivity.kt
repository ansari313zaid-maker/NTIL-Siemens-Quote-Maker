package com.ntil.quotationmaker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.ntil.quotationmaker.data.*
import com.ntil.quotationmaker.excel.ExcelExporter
import com.ntil.quotationmaker.pdf.PdfExporter
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
    
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App() {
        val db = remember { QuotationDatabase.get(this) }
        val priceRepo = remember { SiemensPriceRepository.get(this) }
        val scope = rememberCoroutineScope()
        var q by remember { mutableStateOf(QuotationDraft()) }
        var history by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf("") }

        fun share(file: File, mime: String) {
            val uri = FileProvider.getUriForFile(this, "com.ntil.quotationmaker.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share quotation"))
        }

        MaterialTheme {
            Scaffold(topBar = {
                TopAppBar(title = { Text("NTIL Quotation Master") }, actions = {
                    TextButton(onClick = { history = !history }) { Text(if (history) "New" else "History") }
                })
            }) { pad ->
                if (history) {
                    History(db) { q = it; history = false }
                } else {
                    Column(Modifier.padding(pad).padding(12.dp)) {
                        Text("Quotation Details", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(q.quotationNo, { q = q.copy(quotationNo = it) }, label = { Text("Quotation No.") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(q.customer, { q = q.copy(customer = it) }, label = { Text("Customer") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(q.location, { q = q.copy(location = it) }, label = { Text("Location") }, modifier = Modifier.fillMaxWidth())
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(q.showLpDiscount, { q = q.copy(showLpDiscount = it) })
                            Text("Show LP/MRP & discount on customer quotation")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("BOQ — search Siemens product code; official LP/MRP will fill automatically", style = MaterialTheme.typography.titleMedium)
                        LazyColumn(Modifier.weight(1f)) {
                            itemsIndexed(q.items, key = { i, _ -> i }) { i, item ->
                                BoqRow(item, priceRepo, { ni -> q = q.copy(items = q.items.toMutableList().also { it[i] = ni }) },
                                    { q = q.copy(items = q.items + BoqItem(srNo = (q.items.size + 1).toString())) },
                                    { if (q.items.size > 1) q = q.copy(items = q.items.filterIndexed { idx, _ -> idx != i }) })
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = { scope.launch { db.quotationDao().upsert(QuotationEntity(q.quotationNo, q.date, q.customer, q.location, Json.encodeToString(q))) }; message = "Saved" }) { Text("Save") }
                            Button(onClick = { runCatching { share(PdfExporter.create(this@MainActivity, q), "application/pdf") }.onFailure { message = it.message ?: "PDF error" } }) { Text("PDF") }
                            Button(onClick = { runCatching { share(ExcelExporter.create(this@MainActivity, q), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") }.onFailure { message = it.message ?: "Excel error" } }) { Text("Excel") }
                            if (message.isNotBlank()) Text(message, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun BoqRow(item: BoqItem, repo: SiemensPriceRepository, onChange: (BoqItem) -> Unit, add: () -> Unit, del: () -> Unit) {
        var query by remember(item.srNo, item.productCode) { mutableStateOf(item.productCode) }
        var suggestions by remember { mutableStateOf(emptyList<SiemensProduct>()) }
        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(item.srNo, { onChange(item.copy(srNo = it)) }, label = { Text("Sr") }, modifier = Modifier.width(68.dp))
                    OutlinedTextField(query, {
                        query = it; suggestions = repo.search(it); onChange(item.copy(productCode = it))
                    }, label = { Text("Siemens Product Code") }, modifier = Modifier.weight(1f))
                    Button(onClick = { repo.exactOrNormalized(query)?.let { p -> onChange(item.copy(productCode = p.code, description = p.code, officialPrice = p.price, priceLabel = p.priceLabel)); query = p.code; suggestions = emptyList() } }) { Text("Find") }
                }
                suggestions.take(6).forEach { p ->
                    TextButton(onClick = { onChange(item.copy(productCode = p.code, description = p.code, officialPrice = p.price, priceLabel = p.priceLabel)); query = p.code; suggestions = emptyList() }, modifier = Modifier.fillMaxWidth()) {
                        Text("${p.code}  —  ${p.priceLabel} ₹${"%.2f".format(p.price)}  (p.${p.page})")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(item.qty.toString(), { onChange(item.copy(qty = it.toDoubleOrNull() ?: 0.0)) }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(item.unit, { onChange(item.copy(unit = it)) }, label = { Text("Unit") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(item.purchaseDiscount.toString(), { onChange(item.copy(purchaseDiscount = it.toDoubleOrNull() ?: 0.0)) }, label = { Text("Purchase Disc %") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(item.saleDiscount.toString(), { onChange(item.copy(saleDiscount = it.toDoubleOrNull() ?: 0.0)) }, label = { Text("Sale Disc %") }, modifier = Modifier.weight(1f))
                }
                Text("${item.priceLabel}: ₹%.2f   | Purchase: ₹%.2f   | Sale: ₹%.2f   | Margin: ₹%.2f (%.2f%%)".format(item.officialPrice, item.purchaseRate, item.sellingRate, item.margin, item.marginPercent))
                Row { TextButton(onClick = add) { Text("+ Add BOQ") }; TextButton(onClick = del) { Text("Delete") } }
            }
        }
    }

    @Composable
    private fun History(db: QuotationDatabase, onSelect: (QuotationDraft) -> Unit) {
        val list by db.quotationDao().observeAll().collectAsState(initial = emptyList())
        LazyColumn { items(list) { e -> ListItem(headlineContent = { Text(e.quotationNo) }, supportingContent = { Text("${e.customer} • ${e.date}") }, trailingContent = { TextButton(onClick = { onSelect(Json.decodeFromString(e.json)) }) { Text("Open") } }) } }
    }
}
