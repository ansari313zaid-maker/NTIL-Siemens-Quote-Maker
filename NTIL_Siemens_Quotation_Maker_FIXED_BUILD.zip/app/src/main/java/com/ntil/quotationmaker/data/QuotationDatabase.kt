package com.ntil.quotationmaker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "quotations")
data class QuotationEntity(@PrimaryKey val quotationNo: String, val date: String, val customer: String, val location: String, val json: String, val updatedAt: Long = System.currentTimeMillis())

@Dao
interface QuotationDao {
    @Query("SELECT * FROM quotations ORDER BY updatedAt DESC") fun observeAll(): Flow<List<QuotationEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(q: QuotationEntity)
    @Delete suspend fun delete(q: QuotationEntity)
}

@Database(entities = [QuotationEntity::class], version = 1, exportSchema = false)
abstract class QuotationDatabase : RoomDatabase() {
    abstract fun quotationDao(): QuotationDao
    companion object { @Volatile private var INSTANCE: QuotationDatabase? = null
        fun get(context: android.content.Context) = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(context.applicationContext, QuotationDatabase::class.java, "ntil_quotations.db").build().also { INSTANCE = it } }
    }
}
