package com.ntil.quotationmaker.data

import kotlinx.serialization.Serializable

@Serializable
data class QuotationDraft(
    val quotationNo: String = "",
    val date: String = "",
    val enquiryDate: String = "",
    val customer: String = "",
    val location: String = "",
    val contactPerson: String = "",
    val phone: String = "",
    val email: String = "",
    val salesPerson: String = "Zaid",
    val subject: String = "Supply of Siemens Make Switchgear",
    val paymentTerms: String = "120 days",
    val gstPercent: Double = 18.0,
    val freightCharges: String = "",
    val priceValidity: String = "30 days",
    val warranty: String = "12 months",
    val estimatedDelivery: String = "4–6 weeks",
    val showLpMrp: Boolean = true,
    val showSaleDiscount: Boolean = true,
    val showNetRate: Boolean = true,
    val showAmount: Boolean = true,
    val additionalTermOrder: String = "Order should be placed in the name of Network Techlab India Ltd.",
    val additionalTermLabour: String = "Any Varai / Mathadi / Labour Union charges for unloading/loading material extra.",
    val items: List<BoqItem> = listOf(BoqItem(srNo = "1"))
)

@Serializable
data class BoqItem(
    val srNo: String = "",
    val productCode: String = "",
    val description: String = "",
    val additionalComments: String = "",
    val category: String = "Other Siemens Products",
    val qty: Double = 0.0,
    val unit: String = "Nos",
    val officialPrice: Double = 0.0,
    val priceLabel: String = "LP/MRP",
    val purchaseDiscount: Double = 0.0,
    val saleDiscount: Double = 0.0,
    val stockStatus: String = "Ready Stock"
) {
    val purchaseRate: Double get() = officialPrice * (1.0 - purchaseDiscount / 100.0)
    val sellingRate: Double get() = officialPrice * (1.0 - saleDiscount / 100.0)
    val purchaseAmount: Double get() = purchaseRate * qty
    val sellingAmount: Double get() = sellingRate * qty
    val margin: Double get() = sellingAmount - purchaseAmount
    val marginPercent: Double get() = if (purchaseAmount != 0.0) margin / purchaseAmount * 100.0 else 0.0
    val fullDescription: String get() = listOf(description.trim(), additionalComments.trim()).filter { it.isNotBlank() }.joinToString(" — ")
}
