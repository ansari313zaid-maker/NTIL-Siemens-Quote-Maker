@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.ntil.quotationmaker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.ntil.quotationmaker.data.*
import com.ntil.quotationmaker.excel.ExcelExporter
import com.ntil.quotationmaker.pdf.PdfExporter
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

class MainActivity : ComponentActivity() {
    private var importCallback: ((String) -> Unit)? = null
    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val repo = SiemensPriceRepository.get(this)
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                val r = repo.importPdf(uri)
                importCallback?.invoke("${r.message}: ${r.updated} updated, ${r.added} new")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }

    @Composable private fun App() {
        val db = remember { QuotationDatabase.get(this@MainActivity) }
        val priceRepo = remember { SiemensPriceRepository.get(this@MainActivity) }
        val scope = rememberCoroutineScope()
        var quotation by remember { mutableStateOf(QuotationDraft(quotationNo="NTIL/2026-27/")) }
        var showHistory by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf("") }
        importCallback = { message = it }

        fun shareFile(file: File, mime: String) {
            val uri = FileProvider.getUriForFile(this@MainActivity, "com.ntil.quotationmaker.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type=mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Share quotation"))
        }
        Scaffold(topBar={ TopAppBar(title={Text("NTIL Siemens Quotation Maker")}, actions={
            TextButton(onClick={ pdfPicker.launch(arrayOf("application/pdf")) }) { Text("Import Price PDF") }
            TextButton(onClick={ showHistory=!showHistory; message="" }) { Text(if(showHistory) "New" else "History") }
        }) }) { padding ->
            if(showHistory) HistoryScreen(db){ quotation=it; showHistory=false } else QuotationScreen(
                quotation, priceRepo, padding, message,
                onQuotationChange={quotation=it},
                onSave={ scope.launch { try { db.quotationDao().upsert(QuotationEntity(quotation.quotationNo,quotation.date,quotation.customer,quotation.location,Json.encodeToString(quotation))); message="Quotation Saved" } catch(e:Exception){message=e.message?:"Save Error"} } },
                onPdf={ try { shareFile(PdfExporter.create(this@MainActivity,quotation),"application/pdf") } catch(e:Exception){message=e.message?:"PDF Error"} },
                onExcel={ try { shareFile(ExcelExporter.create(this@MainActivity,quotation),"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") } catch(e:Exception){message=e.message?:"Excel Error"} }
            )
        }
    }

    @Composable private fun QuotationScreen(q: QuotationDraft, repo: SiemensPriceRepository, padding: PaddingValues, message:String, onQuotationChange:(QuotationDraft)->Unit, onSave:()->Unit,onPdf:()->Unit,onExcel:()->Unit) {
        LazyColumn(modifier=Modifier.fillMaxSize().padding(padding).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            item { Section("Customer Details")
                Field("Customer",q.customer){onQuotationChange(q.copy(customer=it))}; Field("Location",q.location){onQuotationChange(q.copy(location=it))}; Field("Contact Person",q.contactPerson){onQuotationChange(q.copy(contactPerson=it))}; Field("Phone No.",q.phone){onQuotationChange(q.copy(phone=it))}; Field("Email ID",q.email){onQuotationChange(q.copy(email=it))}
                Section("Quotation Details"); Field("Quotation No.",q.quotationNo){onQuotationChange(q.copy(quotationNo=it))}; Field("Quotation Date",q.date){onQuotationChange(q.copy(date=it))}; Field("Enquiry Date",q.enquiryDate){onQuotationChange(q.copy(enquiryDate=it))}; Field("Sales Person",q.salesPerson){onQuotationChange(q.copy(salesPerson=it))}; Field("Subject",q.subject){onQuotationChange(q.copy(subject=it))}
                Section("Pricing Display"); Toggle("Show LP/MRP",q.showLpMrp){onQuotationChange(q.copy(showLpMrp=it))}; Toggle("Show Sale Discount",q.showSaleDiscount){onQuotationChange(q.copy(showSaleDiscount=it))}; Toggle("Show Net Rate",q.showNetRate){onQuotationChange(q.copy(showNetRate=it))}; Toggle("Show Amount",q.showAmount){onQuotationChange(q.copy(showAmount=it))}
                Section("Commercial Terms"); Field("Payment Terms",q.paymentTerms){onQuotationChange(q.copy(paymentTerms=it))}; FieldNumber("GST %",q.gstPercent.toString()){onQuotationChange(q.copy(gstPercent=it.toDoubleOrNull()?:0.0))}; Field("Freight Charges (text)",q.freightCharges){onQuotationChange(q.copy(freightCharges=it))}
                Section("Additional Terms"); Field("Price Validity",q.priceValidity){onQuotationChange(q.copy(priceValidity=it))}; Field("Warranty",q.warranty){onQuotationChange(q.copy(warranty=it))}; Field("Estimated Delivery",q.estimatedDelivery){onQuotationChange(q.copy(estimatedDelivery=it))}; Field("Term 4",q.additionalTermOrder){onQuotationChange(q.copy(additionalTermOrder=it))}; Field("Term 5",q.additionalTermLabour){onQuotationChange(q.copy(additionalTermLabour=it))}
                Section("Default Discount Values (blank in new items)")
            }
            itemsIndexed(q.items){index,item -> itemCard(item,repo){changed -> onQuotationChange(q.copy(items=q.items.mapIndexed{ i,x->if(i==index)changed else x }))} }
            item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){Button(onClick={onQuotationChange(q.copy(items=q.items+BoqItem(srNo=(q.items.size+1).toString())))},modifier=Modifier.weight(1f)){Text("Add Item")}; Button(onClick=onSave,modifier=Modifier.weight(1f)){Text("Save")}; Button(onClick=onPdf,modifier=Modifier.weight(1f)){Text("PDF")}; Button(onClick=onExcel,modifier=Modifier.weight(1f)){Text("Excel")}}
                if(message.isNotBlank()) Text(message,modifier=Modifier.padding(6.dp))
            }
        }
    }

    @Composable private fun itemCard(item:BoqItem,repo:SiemensPriceRepository,onChange:(BoqItem)->Unit){
        var cat by remember(item.srNo,item.productCode){mutableStateOf(item.category)}; var catOpen by remember{mutableStateOf(false)}; var query by remember(item.srNo,item.productCode){mutableStateOf(item.productCode)}; var suggestions by remember{mutableStateOf(emptyList<SiemensProduct>())}
        Card { Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text("Item ${item.srNo}",style=MaterialTheme.typography.titleMedium)
            Box { OutlinedTextField(value=cat,onValueChange={},readOnly=true,label={Text("Category")},modifier=Modifier.fillMaxWidth(),trailingIcon={TextButton(onClick={catOpen=true}){Text("▼")}}); DropdownMenu(catOpen,{catOpen=false}){repo.categories().forEach{c->DropdownMenuItem(text={Text(c)},onClick={cat=c;catOpen=false;onChange(item.copy(category=c))})}} }
            Box { OutlinedTextField(value=query,onValueChange={query=it;suggestions=repo.search(it,cat);onChange(item.copy(productCode=it))},label={Text("Product Code / Description Search")},modifier=Modifier.fillMaxWidth()); DropdownMenu(suggestions.isNotEmpty(),{suggestions=emptyList()},modifier=Modifier.fillMaxWidth()){suggestions.forEach{p->DropdownMenuItem(text={Text("${p.code}  •  ${p.priceLabel} ₹${"%.2f".format(p.price)}\n${p.description}")},onClick={query=p.code;suggestions=emptyList();onChange(item.copy(productCode=p.code,officialPrice=p.price,priceLabel=p.priceLabel,description=p.description,category=p.category))})}} }
            Field("Material Description",item.description){onChange(item.copy(description=it))}; Field("Additional Comments",item.additionalComments){onChange(item.copy(additionalComments=it))}
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FieldNumber("Qty",if(item.qty==0.0) "" else item.qty.toString()){onChange(item.copy(qty=it.toDoubleOrNull()?:0.0))}; Field("Unit",item.unit){onChange(item.copy(unit=it))}}
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FieldNumber(item.priceLabel,if(item.officialPrice==0.0) "" else item.officialPrice.toString()){onChange(item.copy(officialPrice=it.toDoubleOrNull()?:0.0))}; FieldNumber("Purchase Disc. %",if(item.purchaseDiscount==0.0) "" else item.purchaseDiscount.toString()){onChange(item.copy(purchaseDiscount=it.toDoubleOrNull()?:0.0))}}
            FieldNumber("Sale Discount %",if(item.saleDiscount==0.0) "" else item.saleDiscount.toString()){onChange(item.copy(saleDiscount=it.toDoubleOrNull()?:0.0))}; Field("Stock Status",item.stockStatus){onChange(item.copy(stockStatus=it))}
            Text("Purchase Rate: ₹%.2f   |   Selling Rate: ₹%.2f".format(item.purchaseRate,item.sellingRate)); Text("Purchase Value: ₹%.2f   |   Selling Value: ₹%.2f".format(item.purchaseAmount,item.sellingAmount)); Text("Margin: ₹%.2f (%.2f%%)".format(item.margin,item.marginPercent))
        }}
    }

    @Composable private fun HistoryScreen(db:QuotationDatabase,onOpen:(QuotationDraft)->Unit){ val rows by db.quotationDao().observeAll().collectAsState(initial=emptyList()); LazyColumn(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Quotation History",style=MaterialTheme.typography.headlineSmall)}; itemsIndexed(rows){_,e->Card{Column(Modifier.padding(12.dp)){Text(e.quotationNo,style=MaterialTheme.typography.titleMedium);Text("${e.date} • ${e.customer} • ${e.location}");Button(onClick={runCatching{onOpen(Json { ignoreUnknownKeys = true }.decodeFromString<QuotationDraft>(e.json))}}){Text("Open")}}}}}}

    @Composable private fun Section(t:String){Text(t,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=6.dp))}
    @Composable private fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},modifier=Modifier.fillMaxWidth())}
    @Composable private fun FieldNumber(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())}
    @Composable private fun Toggle(label:String,value:Boolean,onChange:(Boolean)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Switch(value,onChange);Text(label,Modifier.padding(start=8.dp))}}
}
