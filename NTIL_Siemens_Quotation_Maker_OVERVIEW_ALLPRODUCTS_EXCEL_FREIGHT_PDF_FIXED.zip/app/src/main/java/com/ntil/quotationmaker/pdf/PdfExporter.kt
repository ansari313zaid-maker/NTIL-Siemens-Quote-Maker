package com.ntil.quotationmaker.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.util.Locale

object PdfExporter {
    private val blue = Color.rgb(24, 91, 145)
    private val blueDark = Color.rgb(13, 64, 105)
    private val dark = Color.rgb(35, 45, 55)
    private val light = Color.rgb(235, 243, 249)
    private val border = Color.rgb(150, 170, 185)
    private val muted = Color.rgb(90, 105, 118)

    private fun money(v: Double) = "₹" + String.format(Locale.US, "%,.2f", v)

    private fun wrap(text: String, paint: Paint, max: Float): List<String> {
        val normalized = text.replace("\r", "").split("\n")
        val out = mutableListOf<String>()
        normalized.forEach { para ->
            if (para.isBlank()) { out += ""; return@forEach }
            var current = ""
            para.trim().split(Regex("\\s+")).forEach { word ->
                val next = if (current.isBlank()) word else "$current $word"
                if (paint.measureText(next) > max && current.isNotBlank()) {
                    out += current; current = word
                } else current = next
            }
            if (current.isNotBlank()) out += current
        }
        return if (out.isEmpty()) listOf("") else out
    }

    fun create(context: Context, q: QuotationDraft): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, q.quotationNo.replace("/", "_").ifBlank { "quotation" } + ".pdf")
        val doc = PdfDocument()
        val pageW = 595f; val pageH = 842f; val left = 24f; val right = 571f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var pageNo = 0
        lateinit var page: PdfDocument.Page
        lateinit var canvas: Canvas
        var y = 0f

        fun text(value: String, x: Float, yy: Float, size: Float = 7.5f, bold: Boolean = false, color: Int = dark) {
            p.style = Paint.Style.FILL; p.color = color; p.textSize = size
            p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            canvas.drawText(value, x, yy, p)
        }
        fun rect(x: Float, top: Float, w: Float, h: Float, color: Int, stroke: Boolean = false) {
            p.color = color; p.style = if (stroke) Paint.Style.STROKE else Paint.Style.FILL; p.strokeWidth = 1f
            canvas.drawRect(x, top, x + w, top + h, p); p.style = Paint.Style.FILL
        }
        fun header() {
            rect(0f, 0f, pageW, 78f, blue)
            runCatching {
                val id = context.resources.getIdentifier("ntil_logo", "drawable", context.packageName)
                if (id != 0) BitmapFactory.decodeResource(context.resources, id)?.let { canvas.drawBitmap(it, null, RectF(17f, 9f, 78f, 69f), p) }
            }
            text("Network Techlab India Limited", 88f, 29f, 15.5f, true, Color.WHITE)
            text("Plot No. 142, Rd Number 23, MIDC, Wagle Industrial Estate, Thane West", 88f, 45f, 7.7f, false, Color.WHITE)
            text("Thane, Maharashtra – 400604  |  zaid@netlabindia.com  |  7843852347", 88f, 59f, 7.7f, false, Color.WHITE)
            text("QUOTATION", 245f, 103f, 17f, true, blueDark)
        }
        fun newPage() {
            if (::page.isInitialized) doc.finishPage(page)
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW.toInt(), pageH.toInt(), ++pageNo).create())
            canvas = page.canvas; header(); p.style=Paint.Style.STROKE; p.strokeWidth=1.1f; p.color=blue; canvas.drawRect(12f,12f,583f,830f,p); p.style=Paint.Style.FILL; y = 122f
        }
        fun ensure(h: Float) { if (y + h > 808f) newPage() }
        newPage()

        fun box(x: Float, w: Float, title: String, rows: List<Pair<String,String>>) : Float {
            val rowH = 17f
            val h = 21f + rows.size * rowH + 8f
            rect(x, y, w, h, border, true); rect(x, y, w, 20f, blue)
            text(title, x + 7f, y + 13f, 8f, true, Color.WHITE)
            var yy = y + 34f
            rows.forEach { (label, value) ->
                text("$label:", x + 7f, yy, 6.8f, true)
                p.textSize = 6.8f; p.typeface = Typeface.DEFAULT
                val lines = wrap(value.ifBlank { "—" }, p, w - 104f).take(2)
                lines.forEachIndexed { i, line -> text(line, x + 96f, yy + i * 8f, 6.8f) }
                yy += rowH
            }
            return h
        }

        val top = y
        val leftRows = listOf("Customer" to q.customer, "Location" to q.location, "Contact Person" to q.contactPerson, "Phone" to q.phone, "Email" to q.email)
        val rightRows = listOf("Quotation No." to q.quotationNo, "Quotation Date" to q.date, "Enquiry Date" to q.enquiryDate)
        val leftH = box(left, 266f, "CUSTOMER DETAILS", leftRows)
        y = top
        val rightH = box(305f, 266f, "QUOTATION DETAILS", rightRows)
        y = top + maxOf(leftH, rightH) + 10f

        text("Subject:", left + 4f, y, 7.7f, true, blueDark)
        p.textSize = 7.7f; p.typeface = Typeface.DEFAULT
        val subjectLines = wrap(q.subject.ifBlank { "Supply of Siemens Make Switchgear" }, p, 480f)
        subjectLines.take(2).forEachIndexed { i, line -> text(line, 75f, y + i * 9f, 7.7f) }
        y += 18f + (subjectLines.size - 1).coerceAtLeast(0) * 9f

        fun section(title: String) {
            ensure(31f); rect(left, y, right-left, 18f, blue); text(title, left+7f, y+12f, 8.2f, true, Color.WHITE); y += 27f
        }

        section("BOQ / MATERIAL SHEET")
        // Compact columns deliberately fit inside the page and keep wrapping readable.
        val cols = mutableListOf<Pair<String,Float>>()
        cols += "Sr" to 18f; cols += "Product Code" to 64f; cols += "Description" to 155f; cols += "Qty" to 27f; cols += "Unit" to 27f
        if (q.showLpMrp) cols += "LP/MRP" to 45f
        if (q.showSaleDiscount) cols += "Sale Disc." to 42f
        if (q.showNetRate) cols += "Net Rate" to 54f
        if (q.showAmount) cols += "Amount" to 55f
        cols += "Stock" to 60f
        val tableW = cols.sumOf { it.second.toDouble() }.toFloat()

        fun tableHeader() {
            rect(left, y-9f, tableW, 22f, light)
            var x = left
            cols.forEach { (h,w) ->
                p.textSize = 5.9f; p.typeface = Typeface.DEFAULT_BOLD
                wrap(h, p, w-4f).take(2).forEachIndexed { i,line -> text(line, x+2f, y+1f+i*7f, 5.9f, true, blueDark) }
                x += w
            }
            y += 18f
        }
        tableHeader()

        val basic = q.items.sumOf { it.sellingAmount }
        val taxable = basic + q.freightAmount
        val gst = taxable * q.gstPercent / 100.0

        q.items.forEach { item ->
            p.textSize = 6.2f; p.typeface = Typeface.DEFAULT
            val descParts = mutableListOf<String>()
            if (q.showMaterialDescription && item.description.isNotBlank()) descParts += item.description.trim()
            if (q.showAdditionalComments && item.additionalComments.isNotBlank()) descParts += item.additionalComments.trim()
            if (descParts.isEmpty()) descParts += item.productCode
            val descText = descParts.joinToString("\n")
            val descLines = wrap(descText, p, 151f).take(5)
            val stockLines = wrap(item.stockStatus, p, 55f).take(4)
            val h = maxOf(24f, maxOf(descLines.size, stockLines.size) * 9f + 8f)
            if (y + h > 790f) { newPage(); section("BOQ / MATERIAL SHEET – CONTINUED"); tableHeader() }
            var x = left
            fun cell(value:String, w:Float, size:Float=6.2f, bold:Boolean=false) { wrap(value, p, w-4f).take(4).forEachIndexed { i,line -> text(line,x+2f,y+i*9f,size,bold) }; x += w }
            cell(item.srNo, cols[0].second); cell(item.productCode, cols[1].second); cell(descText, cols[2].second)
            cell(if(item.qty == 0.0) "" else String.format(Locale.US,"%.2f",item.qty), cols[3].second)
            cell(item.unit, cols[4].second)
            if(q.showLpMrp) { cell(money(item.officialPrice), cols.first{it.first=="LP/MRP"}.second, 6.0f); }
            if(q.showSaleDiscount) { cell(if(item.saleDiscount==0.0) "" else String.format(Locale.US,"%.2f%%",item.saleDiscount), cols.first{it.first=="Sale Disc."}.second, 6.0f) }
            if(q.showNetRate) { cell(money(item.sellingRate), cols.first{it.first=="Net Rate"}.second, 6.0f) }
            if(q.showAmount) { cell(money(item.sellingAmount), cols.first{it.first=="Amount"}.second, 6.0f) }
            cell(item.stockStatus, cols.last().second, 6.0f)
            rect(left, y+h-5f, tableW, 0.7f, border)
            y += h
        }

        ensure(100f)
        y += 5f
        fun totalLine(label:String, value:String, bold:Boolean=false) { text(label, 382f, y, 7.5f, bold); text(value, 493f, y, 7.5f, bold); y += 16f }
        totalLine("Basic Quotation Value", money(basic), true)
        totalLine("Freight Charges", if(q.freightAmount != 0.0) money(q.freightAmount) else q.freightCharges.ifBlank{"As per terms"})
        totalLine("Taxable Value", money(taxable), true)
        totalLine("GST @ ${String.format(Locale.US,"%.2f",q.gstPercent)}%", money(gst), true)
        rect(370f, y-4f, 201f, 27f, blueDark)
        text("GRAND TOTAL", 380f, y+13f, 8.5f, true, Color.WHITE); text(money(taxable+gst), 493f, y+13f, 8.5f, true, Color.WHITE); y += 38f

        section("COMMERCIAL TERMS")
        listOf(
            "1. Payment Terms: ${q.paymentTerms}",
            "2. GST: ${String.format(Locale.US,"%.2f",q.gstPercent)}%",
            "3. Freight Charges: ${q.freightCharges.ifBlank{"As per terms"}}${if(q.freightAmount != 0.0) " (₹${String.format(Locale.US,"%,.2f",q.freightAmount)})" else ""}"
        ).forEach { line -> p.textSize=7.2f; wrap(line,p,535f).forEach { ensure(13f); text(it,30f,y,7.2f); y+=11f }; y+=2f }

        section("ADDITIONAL TERMS")
        listOf(
            "1. Price Validity: ${q.priceValidity}",
            "2. Warranty: ${q.warranty}",
            "3. Estimated Delivery: ${q.estimatedDelivery}",
            "4. ${q.additionalTermOrder}",
            "5. ${q.additionalTermLabour}"
        ).forEach { line -> p.textSize=7.2f; wrap(line,p,535f).forEach { ensure(13f); text(it,30f,y,7.2f); y+=11f }; y+=2f }

        section("BANK DETAILS")
        listOf(
            "Bank: ICICI Bank Ltd.",
            "Branch: Shop No. 9, Ground Floor, Jinja Co-Op Society, Opp. Damani Estate, Naupada, Teen Hath Naka – 400604",
            "Branch Name: Thane – Teen Hath Naka Branch",
            "Account Number: 100051000002",
            "IFSC: ICIC00001000",
            "SWIFT: ICICINBBCTS",
            "Account Type: Current Account"
        ).forEach { line -> p.textSize=7.2f; wrap(line,p,535f).forEach { ensure(13f); text(it,30f,y,7.2f); y+=11f }; y+=1f }

        ensure(55f); y += 10f
        text("For Network Techlab India Limited", 400f, y, 7.3f, true); y += 23f
        text("Zaid", 476f, y, 18f, true, blueDark); y += 12f
        text("Authorized Signatory", 453f, y, 7f, false, muted)

        // Full final page border.
        p.style=Paint.Style.STROKE; p.strokeWidth=1.1f; p.color=blue; canvas.drawRect(12f,12f,583f,830f,p); p.style=Paint.Style.FILL
        doc.finishPage(page)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
