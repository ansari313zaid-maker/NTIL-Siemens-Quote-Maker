package com.ntil.quotationmaker.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.util.Locale

object PdfExporter {
    private val blue = Color.rgb(31, 86, 132)
    private val blueDark = Color.rgb(22, 65, 101)
    private val dark = Color.rgb(38, 48, 58)
    private val light = Color.rgb(238, 244, 248)
    private val border = Color.rgb(190, 204, 214)

    private fun money(v: Double) = "₹" + String.format(Locale.US, "%,.2f", v)

    private fun wrap(text: String, paint: Paint, max: Float): List<String> {
        if (text.isBlank()) return listOf("")
        val out = mutableListOf<String>()
        var cur = ""
        text.replace("\n", " ").split(Regex("\\s+")).forEach { w ->
            val t = if (cur.isBlank()) w else "$cur $w"
            if (paint.measureText(t) > max && cur.isNotBlank()) { out += cur; cur = w } else cur = t
        }
        if (cur.isNotBlank()) out += cur
        return out
    }

    fun create(context: Context, q: QuotationDraft): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val name = q.quotationNo.replace("/", "_").ifBlank { "quotation" }
        val file = File(dir, "$name.pdf")
        val doc = PdfDocument()
        var pageNo = 0
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, ++pageNo).create())
        var c = page.canvas
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = 0f

        fun text(value: String, x: Float, yy: Float, size: Float = 7.5f, bold: Boolean = false, color: Int = dark) {
            p.color = color; p.textSize = size; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            c.drawText(value, x, yy, p)
        }

        fun drawTopHeader() {
            p.color = blue; c.drawRect(0f, 0f, 595f, 76f, p)
            runCatching {
                BitmapFactory.decodeResource(context.resources, context.resources.getIdentifier("ntil_logo", "drawable", context.packageName))?.let {
                    c.drawBitmap(it, null, RectF(18f, 9f, 72f, 67f), p)
                }
            }
            text("Network Techlab India Limited", 84f, 28f, 16f, true, Color.WHITE)
            text("Plot No. 142, Rd Number 23, MIDC, Wagle Industrial Estate, Thane West", 84f, 43f, 8.2f, false, Color.WHITE)
            text("Thane, Maharashtra – 400604  |  zaid@netlabindia.com  |  7843852347", 84f, 57f, 8.2f, false, Color.WHITE)
            text("QUOTATION", 238f, 101f, 18f, true, blue)
        }

        fun restartPage() {
            doc.finishPage(page)
            page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, ++pageNo).create())
            c = page.canvas
            drawTopHeader()
            y = 122f
        }

        fun ensure(height: Float) {
            if (y + height > 808f) restartPage()
        }

        fun drawSection(title: String) {
            ensure(32f)
            p.color = blue; c.drawRect(24f, y, 571f, y + 18f, p)
            text(title, 30f, y + 12f, 8.5f, true, Color.WHITE)
            y += 28f
        }

        fun drawBox(x: Float, w: Float, title: String, rows: List<Pair<String, String>>) {
            val rowH = 15f
            val h = 22f + rows.size * rowH + 10f
            p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = border; c.drawRect(x, y, x + w, y + h, p); p.style = Paint.Style.FILL
            p.color = blue; c.drawRect(x, y, x + w, y + 19f, p)
            text(title, x + 7f, y + 13f, 8f, true, Color.WHITE)
            var yy = y + 34f
            rows.forEach { (a, b) ->
                text("$a:", x + 7f, yy, 7.2f, true)
                wrap(b.ifBlank { "—" }, p.apply { textSize = 7.2f; typeface = Typeface.DEFAULT }, w - 105f).take(2).forEachIndexed { i, line ->
                    text(line, x + 96f, yy + i * 9f, 7.2f)
                }
                yy += rowH
            }
        }

        drawTopHeader()
        y = 122f
        // One combined header band: customer details on left, quotation details on right.
        val boxTop = y
        drawBox(24f, 266f, "CUSTOMER DETAILS", listOf(
            "Customer" to q.customer,
            "Location" to q.location,
            "Contact Person" to q.contactPerson,
            "Phone" to q.phone,
            "Email" to q.email
        ))
        val leftBottom = y + 0f
        y = boxTop
        drawBox(305f, 266f, "QUOTATION DETAILS", listOf(
            "Quotation No." to q.quotationNo,
            "Quotation Date" to q.date,
            "Enquiry Date" to q.enquiryDate
        ))
        y = maxOf(leftBottom, y) + 8f

        text("Subject", 30f, y + 2f, 8f, true)
        val subjectLines = wrap(q.subject.ifBlank { "Supply of Siemens Make Switchgear" }, p.apply { textSize = 8f; typeface = Typeface.DEFAULT }, 485f)
        subjectLines.take(2).forEachIndexed { i, line -> text(line, 80f, y + 2f + i * 10f, 8f) }
        y += 18f + (subjectLines.size - 1).coerceAtLeast(0) * 10f

        // Customer-facing BOQ only. Purchase costing and margin remain internal and are never printed.
        drawSection("BOQ / COMMERCIAL OFFER")
        val columns = mutableListOf<Pair<String, Float>>()
        columns += "Sr" to 18f
        columns += "Product Code" to 64f
        columns += "Material Description" to 155f
        columns += "Qty" to 28f
        columns += "Unit" to 28f
        if (q.showLpMrp) columns += "LP/MRP" to 46f
        if (q.showSaleDiscount) columns += "Sale Disc." to 42f
        if (q.showNetRate) columns += "Net Rate" to 55f
        if (q.showAmount) columns += "Amount" to 58f
        columns += "Stock Status" to 53f

        fun drawTableHeader() {
            p.color = light; c.drawRect(24f, y - 10f, 571f, y + 11f, p)
            var x = 24f
            columns.forEach { (h, w) -> text(h, x + 2f, y + 4f, 6.2f, true); x += w }
            y += 21f
        }

        drawTableHeader()
        val basic = q.items.sumOf { it.sellingAmount }
        // IMPORTANT: never print purchase rate, purchase amount, purchase discount, or margin in the PDF.
        q.items.forEach { item ->
            p.textSize = 6.4f; p.typeface = Typeface.DEFAULT
            val descLines = wrap(if (item.fullDescription.isBlank()) item.productCode else item.fullDescription, p, columns.first { it.first == "Material Description" }.second - 5f)
            val stockLines = wrap(item.stockStatus, p, columns.last().second - 5f)
            val lines = maxOf(descLines.size, stockLines.size, 1)
            val h = maxOf(24f, lines * 9f + 8f)
            if (y + h > 790f) { restartPage(); drawSection("BOQ / COMMERCIAL OFFER – CONTINUED"); drawTableHeader() }
            var x = 24f
            text(item.srNo, x + 2f, y, 6.4f); x += columns[0].second
            text(item.productCode.take(18), x + 2f, y, 6.4f); x += columns[1].second
            descLines.forEachIndexed { i, line -> text(line, x + 2f, y + i * 9f, 6.4f) }; x += columns[2].second
            text(String.format(Locale.US, "%.2f", item.qty), x + 2f, y, 6.4f); x += columns[3].second
            text(item.unit.take(8), x + 2f, y, 6.4f); x += columns[4].second
            if (q.showLpMrp) { text(money(item.officialPrice), x + 2f, y, 6.2f); x += columns.first { it.first == "LP/MRP" }.second }
            if (q.showSaleDiscount) { text(if (item.saleDiscount == 0.0) "" else String.format(Locale.US, "%.2f%%", item.saleDiscount), x + 2f, y, 6.2f); x += columns.first { it.first == "Sale Disc." }.second }
            if (q.showNetRate) { text(money(item.sellingRate), x + 2f, y, 6.2f); x += columns.first { it.first == "Net Rate" }.second }
            if (q.showAmount) { text(money(item.sellingAmount), x + 2f, y, 6.2f); x += columns.first { it.first == "Amount" }.second }
            stockLines.forEachIndexed { i, line -> text(line, x + 2f, y + i * 9f, 6.2f) }
            p.color = border; c.drawLine(24f, y + h - 5f, 571f, y + h - 5f, p)
            y += h
        }

        ensure(92f)
        p.color = dark; p.textSize = 8f; p.typeface = Typeface.DEFAULT_BOLD
        text("Basic Quotation Value", 380f, y + 5f, 8f, true); text(money(basic), 500f, y + 5f, 8f, true)
        y += 18f
        text("Freight Charges", 380f, y + 5f, 8f, true); text(q.freightCharges.ifBlank { "As per terms" }, 465f, y + 5f, 7.2f)
        y += 18f
        text("Taxable Value", 380f, y + 5f, 8f, true); text(money(basic), 500f, y + 5f, 8f, true)
        y += 17f
        val gst = basic * q.gstPercent / 100.0
        text("GST @ ${q.gstPercent}%", 380f, y + 5f, 8f, true); text(money(gst), 500f, y + 5f, 8f, true)
        y += 20f
        p.color = blueDark; c.drawRect(370f, y - 4f, 571f, y + 22f, p)
        text("GRAND TOTAL", 380f, y + 12f, 8.5f, true, Color.WHITE); text(money(basic + gst), 500f, y + 12f, 8.5f, true, Color.WHITE)
        y += 34f

        drawSection("COMMERCIAL TERMS")
        listOf(
            "1. Payment Terms: ${q.paymentTerms}",
            "2. GST: ${q.gstPercent}%",
            "3. Freight Charges: ${q.freightCharges.ifBlank { "As per terms" }}"
        ).forEach { line ->
            ensure(15f); text(line, 30f, y, 7.5f); y += 13f
        }

        drawSection("ADDITIONAL TERMS")
        listOf(
            "1. Price Validity: ${q.priceValidity}",
            "2. Warranty: ${q.warranty}",
            "3. Estimated Delivery: ${q.estimatedDelivery}",
            "4. ${q.additionalTermOrder}",
            "5. ${q.additionalTermLabour}"
        ).forEach { line ->
            wrap(line, p.apply { textSize = 7.5f; typeface = Typeface.DEFAULT }, 535f).forEach { wrapped -> ensure(13f); text(wrapped, 30f, y, 7.5f); y += 11f }
            y += 2f
        }

        drawSection("BANK DETAILS")
        listOf(
            "Bank: ICICI Bank Ltd.",
            "Branch: Shop No. 9, Ground Floor, Jinja Co-Op Society, Opp. Damani Estate, Naupada, Teen Hath Naka – 400604",
            "Branch Name: Thane – Teen Hath Naka Branch",
            "Account No.: 100051000002",
            "IFSC: ICIC00001000",
            "SWIFT: ICICINBBCTS",
            "Account Type: Current Account"
        ).forEach { line -> wrap(line, p.apply { textSize = 7.5f; typeface = Typeface.DEFAULT }, 535f).forEach { wrapped -> ensure(13f); text(wrapped, 30f, y, 7.5f); y += 11f } }

        ensure(55f)
        y += 12f
        text("For Network Techlab India Limited", 410f, y, 7.5f, true); y += 24f
        text("Zaid", 475f, y, 18f, true); y += 12f
        text("Authorized Signatory", 458f, y, 7f)

        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f; p.color = blue; c.drawRect(12f, 12f, 583f, 830f, p); p.style = Paint.Style.FILL
        doc.finishPage(page)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
