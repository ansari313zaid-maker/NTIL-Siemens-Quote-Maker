@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.ntil.quotationmaker

import android.content.Intent
import android.os.Bundle
import android.app.DatePickerDialog
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.ntil.quotationmaker.data.*
import com.ntil.quotationmaker.excel.ExcelExporter
import com.ntil.quotationmaker.pdf.PdfExporter
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var importCallback: ((String) -> Unit)? = null
    private var customerImportCallback: ((String) -> Unit)? = null
    private val customerPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val repo = CustomerRepository.get(this)
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                val count = runCatching { repo.importCsv(uri) }.getOrDefault(0)
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    customerImportCallback?.invoke(if (count > 0) "Customer Master imported: $count rows" else "No valid customer rows found. Use CSV/TSV columns: Customer, Location, Contact Person, Phone, Email, Sales Person")
                }
            }
        }
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val repo = SiemensPriceRepository.get(this)
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                val r = repo.importPdf(uri)
                importCallback?.invoke("${r.message}: ${r.updated} updated, ${r.added} new")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scheme = lightColorScheme(
                primary = Color(0xFF245B8F),
                onPrimary = Color.White,
                secondary = Color(0xFF4B6F8F),
                tertiary = Color(0xFF5A7185),
                surface = Color(0xFFF8FAFC),
                surfaceContainerLow = Color(0xFFFFFFFF),
                background = Color(0xFFF5F8FB)
            )
            MaterialTheme(colorScheme = scheme) { App() }
        }
    }

    @Composable private fun App() {
        val db = remember { QuotationDatabase.get(this@MainActivity) }
        val priceRepo = remember { SiemensPriceRepository.get(this@MainActivity) }
        val scope = rememberCoroutineScope()
        var quotation by remember {
                mutableStateOf(QuotationDraft(
                    quotationNo="NTIL/2026-27/",
                    date=SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Calendar.getInstance().time)
                ))
            }
        var showHistory by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf("") }
        importCallback = { message = it }
        customerImportCallback = { message = it }

        fun shareFile(file: File, mime: String) {
            val uri = FileProvider.getUriForFile(this@MainActivity, "com.ntil.quotationmaker.fileprovider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type=mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Share quotation"))
        }
        Scaffold(topBar={ TopAppBar(title={
            Column {
                Text("NTIL Siemens", style=MaterialTheme.typography.titleMedium, fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold)
                Text(if(showHistory) "Quotation History" else "Quotation Maker", style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }, actions={
            TextButton(onClick={ customerPicker.launch(arrayOf("text/csv","text/plain","application/vnd.ms-excel","*/*")) }) { Text("Import Customers") }
            TextButton(onClick={ pdfPicker.launch(arrayOf("application/pdf")) }) { Text("Import Price PDF") }
            TextButton(onClick={ showHistory=!showHistory; message="" }) { Text(if(showHistory) "New" else "History") }
        }) }) { padding ->
            if(showHistory) HistoryScreen(db){ quotation=it; showHistory=false } else QuotationScreen(
                quotation, priceRepo, CustomerRepository.get(this@MainActivity), padding, message,
                onQuotationChange={quotation=it},
                onSave={ scope.launch { try { db.quotationDao().upsert(QuotationEntity(quotation.quotationNo,quotation.date,quotation.customer,quotation.location,Json.encodeToString(quotation))); message="Quotation Saved" } catch(e:Exception){message=e.message?:"Save Error"} } },
                onPdf={ try { shareFile(PdfExporter.create(this@MainActivity,quotation),"application/pdf") } catch(e:Exception){message=e.message?:"PDF Error"} },
                onExcel={ try { shareFile(ExcelExporter.create(this@MainActivity,quotation),"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") } catch(e:Exception){message=e.message?:"Excel Error"} }
            )
        }
    }

    @Composable private fun QuotationScreen(q: QuotationDraft, repo: SiemensPriceRepository, customerRepo: CustomerRepository, padding: PaddingValues, message:String, onQuotationChange:(QuotationDraft)->Unit, onSave:()->Unit,onPdf:()->Unit,onExcel:()->Unit) {
        val primary = Color(0xFF245B8F)
        LazyColumn(modifier=Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp, vertical = 12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Card(shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF2F9))) {
                    Row(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=13.dp), verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Quotation Workspace", style=MaterialTheme.typography.titleMedium, fontWeight=androidx.compose.ui.text.font.FontWeight.Bold, color=MaterialTheme.colorScheme.primary)
                            Text("Prepare, review and export a professional Siemens quotation", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("PDF • Excel", style=MaterialTheme.typography.labelMedium, color=primary, fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold)
                    }
                }
            }
            item {
                AppSectionCard("Customer Details") {
                    var customerMatches by remember { mutableStateOf(emptyList<CustomerProfile>()) }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                        Field("Customer Name",q.customer,Modifier.weight(1f)){
                            val found = customerRepo.exact(it)
                            customerMatches = if (it.isBlank()) emptyList() else customerRepo.search(it)
                            onQuotationChange(if (found != null) q.copy(customer=found.customer,location=found.location,contactPerson=found.contactPerson,phone=found.phone,email=found.email,salesPerson=found.salesPerson.ifBlank{q.salesPerson}) else q.copy(customer=it))
                        }
                        OutlinedButton(onClick={ customerMatches=customerRepo.search(q.customer) }) { Text("Find") }
                    }
                    if (customerMatches.isNotEmpty()) {
                        Card(modifier=Modifier.fillMaxWidth()) { Column(Modifier.heightIn(max=180.dp)) {
                            customerMatches.forEach { c ->
                                DropdownMenuItem(text={Column{Text(c.customer); Text(listOf(c.location,c.contactPerson,c.phone).filter{it.isNotBlank()}.joinToString(" • "),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}},onClick={
                                    customerMatches=emptyList(); onQuotationChange(q.copy(customer=c.customer,location=c.location,contactPerson=c.contactPerson,phone=c.phone,email=c.email,salesPerson=c.salesPerson.ifBlank{q.salesPerson}))
                                })
                            }
                        }}
                    }
                    Field("Location",q.location){onQuotationChange(q.copy(location=it))}
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                        Field("Contact Person",q.contactPerson, Modifier.weight(1f)){onQuotationChange(q.copy(contactPerson=it))}
                        Field("Phone No.",q.phone, Modifier.weight(1f)){onQuotationChange(q.copy(phone=it))}
                    }
                    Field("Email ID",q.email){onQuotationChange(q.copy(email=it))}
                    Field("Sales Person",q.salesPerson){onQuotationChange(q.copy(salesPerson=it))}
                }
            }
            item {
                AppSectionCard("Quotation Details") {
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                        Field("Quotation No.",q.quotationNo, Modifier.weight(1f)){onQuotationChange(q.copy(quotationNo=it))}
                        DateField("Quotation Date",q.date, Modifier.weight(1f)){onQuotationChange(q.copy(date=it))}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                        DateField("Enquiry Date",q.enquiryDate, Modifier.weight(1f)){onQuotationChange(q.copy(enquiryDate=it))}
                        Spacer(Modifier.weight(1f))
                    }
                    Field("Subject",q.subject){onQuotationChange(q.copy(subject=it))}
                }
            }
            item {
                AppSectionCard("Customer-Facing Pricing") {
                    Text("Select only the columns you want printed on the quotation.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Toggle("Show LP/MRP",q.showLpMrp){onQuotationChange(q.copy(showLpMrp=it))}
                    Toggle("Show Sale Discount",q.showSaleDiscount){onQuotationChange(q.copy(showSaleDiscount=it))}
                    Toggle("Show Net Rate",q.showNetRate){onQuotationChange(q.copy(showNetRate=it))}
                    Toggle("Show Amount",q.showAmount){onQuotationChange(q.copy(showAmount=it))}
                }
            }
            item {
                AppSectionCard("Commercial Terms") {
                    Field("Payment Terms",q.paymentTerms){onQuotationChange(q.copy(paymentTerms=it))}
                    FieldNumber("GST %",if(q.gstPercent==0.0) "" else q.gstPercent.toString()){onQuotationChange(q.copy(gstPercent=it.toDoubleOrNull()?:0.0))}
                    Field("Freight Charges / Terms",q.freightCharges){onQuotationChange(q.copy(freightCharges=it))}
                    FieldNumber("Freight Charges Amount (₹)",if(q.freightAmount==0.0) "" else q.freightAmount.toString()){onQuotationChange(q.copy(freightAmount=it.toDoubleOrNull()?:0.0))}
                    Text("Freight amount is added to Basic Value before GST and does not affect item rates.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                AppSectionCard("Additional Terms") {
                    Field("Price Validity",q.priceValidity){onQuotationChange(q.copy(priceValidity=it))}
                    Field("Warranty",q.warranty){onQuotationChange(q.copy(warranty=it))}
                    Field("Estimated Delivery",q.estimatedDelivery){onQuotationChange(q.copy(estimatedDelivery=it))}
                    Field("Term 4",q.additionalTermOrder){onQuotationChange(q.copy(additionalTermOrder=it))}
                    Field("Term 5",q.additionalTermLabour){onQuotationChange(q.copy(additionalTermLabour=it))}
                }
            }
            itemsIndexed(q.items){index,item -> itemCard(item,repo){changed -> onQuotationChange(q.copy(items=q.items.mapIndexed{ i,x->if(i==index)changed else x }))} }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    Button(onClick={onQuotationChange(q.copy(items=q.items+BoqItem(srNo=(q.items.size+1).toString())))},modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)){Text("+ Add Item")}
                    Button(onClick=onSave,modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)){Text("Save")}
                    Button(onClick=onPdf,modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)){Text("PDF")}
                    Button(onClick=onExcel,modifier=Modifier.weight(1f), shape=RoundedCornerShape(12.dp)){Text("Excel")}
                }
                if(message.isNotBlank()) Text(message,modifier=Modifier.padding(8.dp),color=primary,style=MaterialTheme.typography.bodyMedium)
            }
        }
    }

    @Composable private fun itemCard(item:BoqItem,repo:SiemensPriceRepository,onChange:(BoqItem)->Unit){
        var cat by remember(item.srNo,item.productCode){mutableStateOf(item.category)}
        var catOpen by remember{mutableStateOf(false)}
        var query by remember(item.srNo,item.productCode){mutableStateOf(item.productCode)}
        var suggestions by remember{mutableStateOf(emptyList<SiemensProduct>())}
        Card(shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceContainerLow), elevation=CardDefaults.cardElevation(defaultElevation=2.dp)) {
            Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                    Surface(shape=RoundedCornerShape(8.dp), color=Color(0xFF245B8F)) {
                        Text("${item.srNo}", color=Color.White, style=MaterialTheme.typography.labelLarge, fontWeight=androidx.compose.ui.text.font.FontWeight.Bold, modifier=Modifier.padding(horizontal=9.dp, vertical=5.dp))
                    }
                    Column(Modifier.weight(1f).padding(start=10.dp)) {
                        Text("Material Item",style=MaterialTheme.typography.titleMedium,fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold)
                        Text("Customer quotation pricing",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedTextField(value=cat,onValueChange={},readOnly=true,label={Text("Category")},modifier=Modifier.fillMaxWidth(),trailingIcon={TextButton(onClick={catOpen=true}){Text("▼")}})
                    DropdownMenu(expanded=catOpen,onDismissRequest={catOpen=false}){repo.categories().forEach{c->DropdownMenuItem(text={Text(c)},onClick={cat=c;catOpen=false;onChange(item.copy(category=c))})}}
                }
                // Search remains visible at all times; results are rendered below it instead of covering the field.
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                    OutlinedTextField(value=query,onValueChange={
                        query=it
                        suggestions=if(it.isBlank()) emptyList() else repo.search(it,cat)
                        val found=repo.exactOrNormalized(it)
                        if(found!=null) onChange(item.copy(productCode=found.code,officialPrice=found.price,priceLabel=found.priceLabel,description=found.description,category=found.category)) else onChange(item.copy(productCode=it))
                    },label={Text("Product Code / Description Search")},modifier=Modifier.weight(1f),singleLine=true)
                    OutlinedButton(onClick={suggestions=if(query.isBlank()) emptyList() else repo.search(query,cat)}) { Text("Find") }
                }
                if(suggestions.isNotEmpty()) {
                    Card(shape=RoundedCornerShape(10.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface), modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.heightIn(max=190.dp)) {
                            suggestions.take(8).forEach { p ->
                                DropdownMenuItem(
                                    text={Column{Text(p.code,style=MaterialTheme.typography.bodyMedium);if(p.description.isNotBlank())Text(p.description,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=2)}},
                                    onClick={query=p.code;suggestions=emptyList();onChange(item.copy(productCode=p.code,officialPrice=p.price,priceLabel=p.priceLabel,description=p.description,category=p.category))}
                                )
                            }
                        }
                    }
                }
                Field("Material Description",item.description){onChange(item.copy(description=it))}
                Field("Additional Comments",item.additionalComments){onChange(item.copy(additionalComments=it))}
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    FieldNumber("Qty",if(item.qty==0.0) "" else item.qty.toString(), Modifier.weight(1f).height(58.dp)){onChange(item.copy(qty=it.toDoubleOrNull()?:0.0))}
                    Field("Unit",item.unit, Modifier.weight(1f).height(58.dp)){onChange(item.copy(unit=it))}
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    FieldNumber(item.priceLabel,if(item.officialPrice==0.0) "" else item.officialPrice.toString(), Modifier.weight(1f)){onChange(item.copy(officialPrice=it.toDoubleOrNull()?:0.0))}
                    // Purchase discount is available for calculation but is deliberately NOT printed in the customer quotation.
                    FieldNumber("Purchase Disc. %",if(item.purchaseDiscount==0.0) "" else item.purchaseDiscount.toString(), Modifier.weight(1f)){onChange(item.copy(purchaseDiscount=it.toDoubleOrNull()?:0.0))}
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    FieldNumber("Sale Discount %",if(item.saleDiscount==0.0) "" else item.saleDiscount.toString(), Modifier.weight(1f)){onChange(item.copy(saleDiscount=it.toDoubleOrNull()?:0.0))}
                    Field("Stock Status",item.stockStatus, Modifier.weight(1f)){onChange(item.copy(stockStatus=it))}
                }
                HorizontalDivider()
                Surface(shape=RoundedCornerShape(10.dp), color=Color(0xFFF4F7FA), modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                        Text("Internal Costing", style=MaterialTheme.typography.labelLarge, fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold, color=MaterialTheme.colorScheme.primary)
                        Text("Purchase Rate  ₹%.2f    |    Purchase Value  ₹%.2f".format(item.purchaseRate,item.purchaseAmount), style=MaterialTheme.typography.bodySmall)
                        Text("Selling Rate  ₹%.2f    |    Selling Value  ₹%.2f".format(item.sellingRate,item.sellingAmount), style=MaterialTheme.typography.bodySmall)
                        Text("Margin  ₹%.2f (%.2f%%)".format(item.margin,item.marginPercent), style=MaterialTheme.typography.bodySmall, fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    @Composable private fun AppSectionCard(title:String, content:@Composable ColumnScope.()->Unit){
        Card(shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceContainerLow), elevation=CardDefaults.cardElevation(defaultElevation=1.dp)){
            Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text(title,style=MaterialTheme.typography.titleMedium,fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold)
                HorizontalDivider()
                content()
            }
        }
    }

    @Composable private fun HistoryScreen(db:QuotationDatabase,onOpen:(QuotationDraft)->Unit){ val rows by db.quotationDao().observeAll().collectAsState(initial=emptyList()); LazyColumn(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Quotation History",style=MaterialTheme.typography.headlineSmall)}; itemsIndexed(rows){_,e->Card{Column(Modifier.padding(12.dp)){Text(e.quotationNo,style=MaterialTheme.typography.titleMedium);Text("${e.date} • ${e.customer} • ${e.location}");Button(onClick={runCatching{onOpen(Json { ignoreUnknownKeys = true }.decodeFromString<QuotationDraft>(e.json))}}){Text("Open")}}}}}}

    @Composable private fun Section(t:String){Text(t,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=6.dp))}
    @Composable private fun DateField(label:String,value:String,modifier:Modifier=Modifier.fillMaxWidth(),onChange:(String)->Unit){
        val formatter=remember { SimpleDateFormat("dd/MM/yyyy", Locale.US) }
        OutlinedTextField(value=value,onValueChange={},readOnly=true,label={Text(label)},modifier=modifier,trailingIcon={
            TextButton(onClick={
                val cal=Calendar.getInstance()
                runCatching { if(value.isNotBlank()) cal.time=formatter.parse(value) ?: cal.time }
                DatePickerDialog(this@MainActivity,{_,year,month,day->
                    val picked=Calendar.getInstance().apply{set(year,month,day)}
                    onChange(formatter.format(picked.time))
                },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
            }) { Text("📅") }
        })
    }
    @Composable private fun Field(label:String,value:String,modifier:Modifier=Modifier.fillMaxWidth(),onChange:(String)->Unit){OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},modifier=modifier)}
    @Composable private fun FieldNumber(label:String,value:String,modifier:Modifier=Modifier.fillMaxWidth(),onChange:(String)->Unit){OutlinedTextField(value=value,onValueChange=onChange,label={Text(label)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=modifier)}
    @Composable private fun Toggle(label:String,value:Boolean,onChange:(Boolean)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Switch(value,onChange);Text(label,Modifier.padding(start=8.dp))}}
}
