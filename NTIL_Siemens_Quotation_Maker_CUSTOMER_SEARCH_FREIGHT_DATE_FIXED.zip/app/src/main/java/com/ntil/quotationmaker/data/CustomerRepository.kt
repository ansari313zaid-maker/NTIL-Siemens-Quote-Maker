package com.ntil.quotationmaker.data

import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

/** Offline customer master. Import CSV/TSV with columns: Customer, Location, Contact Person, Phone, Email, Sales Person. */
data class CustomerProfile(
    val customer: String,
    val location: String = "",
    val contactPerson: String = "",
    val phone: String = "",
    val email: String = "",
    val salesPerson: String = ""
)

class CustomerRepository private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("customer_master", Context.MODE_PRIVATE)
    private var customers: MutableList<CustomerProfile> = mutableListOf()

    init { reload() }

    @Synchronized fun reload() {
        customers = prefs.getStringSet("rows", emptySet())!!.mapNotNull { decode(it) }.toMutableList()
    }

    fun all(): List<CustomerProfile> = customers.toList()

    fun search(query: String, limit: Int = 8): List<CustomerProfile> {
        val q = query.trim().uppercase(Locale.US)
        if (q.isBlank()) return emptyList()
        return customers.asSequence()
            .filter { it.customer.uppercase(Locale.US).contains(q) }
            .sortedWith(compareBy<CustomerProfile> { if (it.customer.equals(query.trim(), true)) 0 else 1 }.thenBy { it.customer })
            .take(limit).toList()
    }

    fun exact(query: String): CustomerProfile? = customers.firstOrNull { it.customer.equals(query.trim(), true) }

    fun importCsv(uri: Uri): Int {
        val input = context.contentResolver.openInputStream(uri) ?: return 0
        val imported = mutableListOf<CustomerProfile>()
        input.use { stream ->
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).useLines { lines ->
                val rows = lines.toList().filter { it.isNotBlank() }
                if (rows.isEmpty()) return@useLines
                val delimiter = if (rows.first().contains('\t')) '\t' else ','
                val header = splitRow(rows.first(), delimiter).map { it.trim().lowercase(Locale.US) }
                val idxCustomer = header.indexOfFirst { it in setOf("customer", "customer name", "name") }
                val idxLocation = header.indexOfFirst { it == "location" || it == "city" }
                val idxContact = header.indexOfFirst { it.contains("contact") }
                val idxPhone = header.indexOfFirst { it.contains("phone") || it.contains("mobile") }
                val idxEmail = header.indexOfFirst { it.contains("email") }
                val idxSales = header.indexOfFirst { it.contains("sales") }
                if (idxCustomer < 0) return@useLines
                rows.drop(1).forEach { row ->
                    val p = splitRow(row, delimiter)
                    val customer = p.getOrNull(idxCustomer)?.trim().orEmpty()
                    if (customer.isNotBlank()) imported += CustomerProfile(
                        customer,
                        p.getOrNull(idxLocation)?.trim().orEmpty(),
                        p.getOrNull(idxContact)?.trim().orEmpty(),
                        p.getOrNull(idxPhone)?.trim().orEmpty(),
                        p.getOrNull(idxEmail)?.trim().orEmpty(),
                        p.getOrNull(idxSales)?.trim().orEmpty()
                    )
                }
            }
        }
        if (imported.isEmpty()) return 0
        val merged = (customers + imported).associateBy { it.customer.trim().uppercase(Locale.US) }.values.sortedBy { it.customer }.toList()
        customers = merged.toMutableList()
        prefs.edit().putStringSet("rows", merged.map { encode(it) }.toSet()).apply()
        return imported.size
    }

    private fun splitRow(row: String, delimiter: Char): List<String> {
        if (delimiter == '\t') return row.split('\t')
        val out = mutableListOf<String>(); val sb = StringBuilder(); var quoted = false; var i = 0
        while (i < row.length) {
            val ch = row[i]
            if (ch == '"') {
                if (quoted && i + 1 < row.length && row[i + 1] == '"') { sb.append('"'); i++ } else quoted = !quoted
            } else if (ch == ',' && !quoted) { out += sb.toString(); sb.clear() } else sb.append(ch)
            i++
        }
        out += sb.toString(); return out
    }

    private fun encode(p: CustomerProfile) = listOf(p.customer,p.location,p.contactPerson,p.phone,p.email,p.salesPerson).joinToString("\u001f")
    private fun decode(s: String): CustomerProfile? { val p=s.split('\u001f'); return if (p.isNotEmpty() && p[0].isNotBlank()) CustomerProfile(p[0],p.getOrElse(1){""},p.getOrElse(2){""},p.getOrElse(3){""},p.getOrElse(4){""},p.getOrElse(5){""}) else null }

    companion object {
        @Volatile private var INSTANCE: CustomerRepository? = null
        fun get(context: Context): CustomerRepository = INSTANCE ?: synchronized(this) { INSTANCE ?: CustomerRepository(context.applicationContext).also { INSTANCE = it } }
    }
}
