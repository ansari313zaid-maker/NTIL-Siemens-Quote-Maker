@file:OptIn(androidx.compose.material3.
ExperimentalMaterial3Api::class)

package com.ntil.quotationmaker
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.ntil.quotationmaker.data.BoqItem
import com.ntil.quotationmaker.data.QuotationDatabase
import com.ntil.quotationmaker.data.QuotationDraft
import com.ntil.quotationmaker.data.QuotationEntity
import com.ntil.quotationmaker.data.SiemensPriceRepository
import com.ntil.quotationmaker.data.SiemensProduct
import com.ntil.quotationmaker.excel.ExcelExporter
import com.ntil.quotationmaker.pdf.PdfExporter
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                App()
            }
        }
    }

    @Composable
    private fun App() {

        val db = remember {
            QuotationDatabase.get(this@MainActivity)
        }

        val priceRepo = remember {
            SiemensPriceRepository.get(this@MainActivity)
        }

        val scope = rememberCoroutineScope()

        var quotation by remember {
            mutableStateOf(
                QuotationDraft(
                    quotationNo = "NTIL/2026-27/",
                    paymentTerms = "120 days",
                    gstPercent = 18.0,
                    stockStatus = "Ready Stock"
                )
            )
        }

        var showHistory by remember {
            mutableStateOf(false)
        }

        var message by remember {
            mutableStateOf("")
        }

        fun shareFile(
            file: File,
            mimeType: String
        ) {

            val uri = FileProvider.getUriForFile(
                this@MainActivity,
                "com.ntil.quotationmaker.fileprovider",
                file
            )

            val shareIntent =
                Intent(Intent.ACTION_SEND).apply {

                    type = mimeType

                    putExtra(
                        Intent.EXTRA_STREAM,
                        uri
                    )

                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }

            startActivity(
                Intent.createChooser(
                    shareIntent,
                    "Share quotation"
                )
            )
        }

        Scaffold(

            topBar = {

                TopAppBar(

                    title = {
                        Text(
                            "NTIL Quotation Master"
                        )
                    },

                    actions = {

                        TextButton(
                            onClick = {

                                showHistory =
                                    !showHistory

                                message = ""
                            }
                        ) {

                            Text(
                                if (showHistory) {
                                    "New"
                                } else {
                                    "History"
                                }
                            )
                        }
                    }
                )
            }

        ) { padding ->

            if (showHistory) {

                HistoryScreen(
                    db = db,
                    onOpen = { savedQuotation ->

                        quotation =
                            savedQuotation

                        showHistory = false

                        message = ""
                    }
                )

            } else {

                QuotationScreen(

                    quotation = quotation,

                    priceRepo = priceRepo,

                    padding = padding,

                    message = message,

                    onQuotationChange = {
                        quotation = it
                    },

                    onSave = {

                        scope.launch {

                            try {

                                db.quotationDao().upsert(

                                    QuotationEntity(

                                        quotationNo =
                                            quotation.quotationNo,

                                        date =
                                            quotation.date,

                                        customer =
                                            quotation.customer,

                                        location =
                                            quotation.location,

                                        json =
                                            Json.encodeToString(
                                                quotation
                                            )
                                    )
                                )

                                message =
                                    "Quotation Saved"

                            } catch (e: Exception) {

                                message =
                                    e.message
                                        ?: "Save Error"
                            }
                        }
                    },

                    onPdf = {

                        try {

                            val file =
                                PdfExporter.create(
                                    this@MainActivity,
                                    quotation
                                )

                            shareFile(
                                file,
                                "application/pdf"
                            )

                        } catch (e: Exception) {

                            message =
                                e.message
                                    ?: "PDF Error"
                        }
                    },

                    onExcel = {

                        try {

                            val file =
                                ExcelExporter.create(
                                    this@MainActivity,
                                    quotation
                                )

                            shareFile(
                                file,
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )

                        } catch (e: Exception) {

                            message =
                                e.message
                                    ?: "Excel Error"
                        }
                    }
                )
            }
        }
    }

    @Composable
    private fun QuotationScreen(

        quotation: QuotationDraft,

        priceRepo: SiemensPriceRepository,

        padding: PaddingValues,

        message: String,

        onQuotationChange:
            (QuotationDraft) -> Unit,

        onSave: () -> Unit,

        onPdf: () -> Unit,

        onExcel: () -> Unit

    ) {

        Column(

            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(12.dp)
        ) {

            LazyColumn(

                modifier =
                    Modifier.weight(1f),

                verticalArrangement =
                    Arrangement.spacedBy(6.dp)
            ) {

                item {

                    Text(
                        "Quotation Details",
                        style =
                            MaterialTheme
                                .typography
                                .titleMedium
                    )

                    Spacer(
                        Modifier.height(6.dp)
                    )

                    OutlinedTextField(

                        value =
                            quotation.quotationNo,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    quotationNo = it
                                )
                            )
                        },

                        label = {
                            Text("Quotation No.")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.date,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    date = it
                                )
                            )
                        },

                        label = {
                            Text("Date")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    Spacer(
                        Modifier.height(8.dp)
                    )

                    Text(
                        "Customer Details",
                        style =
                            MaterialTheme
                                .typography
                                .titleMedium
                    )

                    OutlinedTextField(

                        value =
                            quotation.customer,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    customer = it
                                )
                            )
                        },

                        label = {
                            Text("Customer Name")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.location,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    location = it
                                )
                            )
                        },

                        label = {
                            Text("Location")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.contactPerson,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    contactPerson = it
                                )
                            )
                        },

                        label = {
                            Text("Contact Person")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.phone,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    phone = it
                                )
                            )
                        },

                        label = {
                            Text("Phone No.")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.email,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    email = it
                                )
                            )
                        },

                        label = {
                            Text("Email ID")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    Spacer(
                        Modifier.height(8.dp)
                    )

                    Text(
                        "Commercial Terms",
                        style =
                            MaterialTheme
                                .typography
                                .titleMedium
                    )

                    OutlinedTextField(

                        value =
                            quotation.paymentTerms,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    paymentTerms = it
                                )
                            )
                        },

                        label = {
                            Text("Payment Terms")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.gstPercent
                                .toString(),

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    gstPercent =
                                        it.toDoubleOrNull()
                                            ?: 0.0
                                )
                            )
                        },

                        label = {
                            Text("GST %")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.freightCharges
                                .toString(),

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    freightCharges =
                                        it.toDoubleOrNull()
                                            ?: 0.0
                                )
                            )
                        },

                        label = {
                            Text("Freight Charges")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(

                        value =
                            quotation.stockStatus,

                        onValueChange = {

                            onQuotationChange(
                                quotation.copy(
                                    stockStatus = it
                                )
                            )
                        },

                        label = {
                            Text("Stock Status")
                        },

                        modifier =
                            Modifier.fillMaxWidth()
                    )

                    Row(

                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Checkbox(

                            checked =
                                quotation.showLpDiscount,

                            onCheckedChange = {

                                onQuotationChange(
                                    quotation.copy(
                                        showLpDiscount =
                                            it
                                    )
                                )
                            }
                        )

                        Text(
                            "Show LP/MRP & discount on quotation"
                        )
                    }

                    Spacer(
                        Modifier.height(8.dp)
                    )

                    Text(
                        "BOQ",
                        style =
                            MaterialTheme
                                .typography
                                .titleMedium
                    )

                    Text(
                        "Search Siemens product code; official LP/MRP will fill automatically.",
                        style =
                            MaterialTheme
                                .typography
                                .bodySmall
                    )
                }

                itemsIndexed(

                    quotation.items,

                    key = { index, _ ->
                        index
                    }

                ) { index, item ->

                    BoqRow(

                        item = item,

                        repo = priceRepo,

                        onChange = { newItem ->

                            val list =
                                quotation.items
                                    .toMutableList()

                            list[index] =
                                newItem

                            onQuotationChange(
                                quotation.copy(
                                    items = list
                                )
                            )
                        },

                        onAdd = {

                            onQuotationChange(

                                quotation.copy(

                                    items =
                                        quotation.items +
                                            BoqItem(
                                                srNo =
                                                    (
                                                        quotation.items.size +
                                                            1
                                                    ).toString()
                                            )
                                )
                            )
                        },

                        onDelete = {

                            if (
                                quotation.items.size > 1
                            ) {

                                val list =
                                    quotation.items
                                        .filterIndexed {
                                            i, _ ->
                                            i != index
                                        }
                                        .mapIndexed {
                                            i, value ->

                                            value.copy(
                                                srNo =
                                                    (
                                                        i + 1
                                                    ).toString()
                                            )
                                        }

                                onQuotationChange(
                                    quotation.copy(
                                        items = list
                                    )
                                )
                            }
                        }
                    )
                }
            }

            Spacer(
                Modifier.height(6.dp)
            )

            if (message.isNotBlank()) {

                Text(
                    text = message,
                    modifier =
                        Modifier.padding(6.dp)
                )
            }

            Row(

                modifier =
                    Modifier.fillMaxWidth(),

                horizontalArrangement =
                    Arrangement.spacedBy(6.dp)
            ) {

                Button(

                    onClick = onSave,

                    modifier =
                        Modifier.weight(1f)
                ) {
                    Text("Save")
                }

                Button(

                    onClick = onPdf,

                    modifier =
                        Modifier.weight(1f)
                ) {
                    Text("PDF")
                }

                Button(

                    onClick = onExcel,

                    modifier =
                        Modifier.weight(1f)
                ) {
                    Text("Excel")
                }
            }
        }
    }

    @Composable
    private fun BoqRow(

        item: BoqItem,

        repo: SiemensPriceRepository,

        onChange:
            (BoqItem) -> Unit,

        onAdd: () -> Unit,

        onDelete: () -> Unit

    ) {

        var query by remember(

            item.srNo,

            item.productCode

        ) {

            mutableStateOf(
                item.productCode
            )
        }

        var suggestions by remember {

            mutableStateOf(
                emptyList<SiemensProduct>()
            )
        }

        Card(

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Column(

                modifier =
                    Modifier.padding(8.dp)
            ) {

                Row(

                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp),

                    verticalAlignment =
                        Alignment.Top
                ) {

                    OutlinedTextField(

                        value =
                            item.srNo,

                        onValueChange = {

                            onChange(
                                item.copy(
                                    srNo = it
                                )
                            )
                        },

                        label = {
                            Text("Sr")
                        },

                        modifier =
                            Modifier.width(65.dp)
                    )

                    Box(

                        modifier =
                            Modifier.weight(1f)
                    ) {

                        OutlinedTextField(

                            value =
                                query,

                            onValueChange = {

                                query = it

                                suggestions =

                                    if (
                                        it.length >= 2
                                    ) {

                                        repo.search(it)

                                    } else {

                                        emptyList()
                                    }

                                onChange(
                                    item.copy(
                                        productCode =
                                            it
                                    )
                                )
                            },

                            label = {
                                Text(
                                    "Siemens Product Code"
                                )
                            },

                            modifier =
                                Modifier.fillMaxWidth()
                        )

                        DropdownMenu(

                            expanded =
                                suggestions
                                    .isNotEmpty(),

                            onDismissRequest = {

                                suggestions =
                                    emptyList()
                            },

                            modifier =
                                Modifier.fillMaxWidth()
                        ) {

                            suggestions.forEach {

                                product ->

                                DropdownMenuItem(

                                    text = {

                                        Text(
                                            "${product.code} • ${product.priceLabel} ₹${product.price}"
                                        )
                                    },

                                    onClick = {

                                        query =
                                            product.code

                                        suggestions =
                                            emptyList()

                                        onChange(

                                            item.copy(

                                                productCode =
                                                    product.code,

                                                officialPrice =
                                                    product.price,

                                                priceLabel =
                                                    product.priceLabel
                                            )
                                        )
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(
                    Modifier.height(6.dp)
                )

                OutlinedTextField(

                    value =
                        item.description,

                    onValueChange = {

                        onChange(
                            item.copy(
                                description = it
                            )
                        )
                    },

                    label = {
                        Text("Description")
                    },

                    modifier =
                        Modifier.fillMaxWidth()
                )

                Row(

                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    OutlinedTextField(

                        value =
                            item.qty.toString(),

                        onValueChange = {

                            onChange(
                                item.copy(
                                    qty =
                                        it.toDoubleOrNull()
                                            ?: 0.0
                                )
                            )
                        },

                        label = {
                            Text("Qty")
                        },

                        modifier =
                            Modifier.weight(1f)
                    )

                    OutlinedTextField(

                        value =
                            item.unit,

                        onValueChange = {

                            onChange(
                                item.copy(
                                    unit = it
                                )
                            )
                        },

                        label = {
                            Text("Unit")
                        },

                        modifier =
                            Modifier.weight(1f)
                    )
                }

                Row(

                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    OutlinedTextField(

                        value =
                            item.officialPrice
                                .toString(),

                        onValueChange = {

                            onChange(
                                item.copy(
                                    officialPrice =
                                        it.toDoubleOrNull()
                                            ?: 0.0
                                )
                            )
                        },

                        label = {
                            Text(
                                item.priceLabel
                            )
                        },

                        modifier =
                            Modifier.weight(1f)
                    )

                    OutlinedTextField(

                        value =
                            item.purchaseDiscount
                                .toString(),

                        onValueChange = {

                            onChange(
                                item.copy(
                                    purchaseDiscount =
                                        it.toDoubleOrNull()
                                            ?: 0.0
                                )
                            )
                        },

                        label = {
                            Text(
                                "Purchase Disc. %"
                            )
                        },

                        modifier =
                            Modifier.weight(1f)
                    )
                }

                OutlinedTextField(

                    value =
                        item.saleDiscount
                            .toString(),

                    onValueChange = {

                        onChange(
                            item.copy(
                                saleDiscount =
                                    it.toDoubleOrNull()
                                        ?: 0.0
                            )
                        )
                    },

                    label = {
                        Text(
                            "Sale Discount %"
                        )
                    },

                    modifier =
                        Modifier.fillMaxWidth()
                )

                Spacer(
                    Modifier.height(6.dp)
                )

                Text(
                    "Purchase Rate: ₹%.2f"
                        .format(
                            item.purchaseRate
                        )
                )

                Text(
                    "Selling Rate: ₹%.2f"
                        .format(
                            item.sellingRate
                        )
                )

                Text(
                    "Purchase Amount: ₹%.2f"
                        .format(
                            item.purchaseAmount
                        )
                )

                Text(
                    "Selling Amount: ₹%.2f"
                        .format(
                            item.sellingAmount
                        )
                )

                Text(
                    "Margin: ₹%.2f (%.2f%%)"
                        .format(
                            item.margin,
                            item.marginPercent
                        )
                )

                Spacer(
                    Modifier.height(6.dp)
                )

                Row(

                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    OutlinedButton(

                        onClick = onAdd,

                        modifier =
                            Modifier.weight(1f)
                    ) {
                        Text("Add Item")
                    }

                    OutlinedButton(

                        onClick = onDelete,

                        modifier =
                            Modifier.weight(1f)
                    ) {
                        Text("Delete")
                    }
                }
            }
        }
    }

    @Composable
    private fun HistoryScreen(

        db: QuotationDatabase,

        onOpen:
            (QuotationDraft) -> Unit

    ) {

        val quotations by
            db.quotationDao()
                .observeAll()
                .collectAsState(
                    initial = emptyList()
                )

        Column(

            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(12.dp)
        ) {

            Text(

                "Quotation History",

                style =
                    MaterialTheme
                        .typography
                        .headlineSmall
            )

            Spacer(
                Modifier.height(10.dp)
            )

            if (quotations.isEmpty()) {

                Text(
                    "No saved quotations."
                )

            } else {

                LazyColumn(

                    verticalArrangement =
                        Arrangement.spacedBy(8.dp)
                ) {

                    itemsIndexed(
                        quotations
                    ) { _, entity ->

                        Card(

                            modifier =
                                Modifier.fillMaxWidth()
                        ) {

                            Column(

                                modifier =
                                    Modifier.padding(12.dp)
                            ) {

                                Text(

                                    entity.quotationNo,

                                    style =
                                        MaterialTheme
                                            .typography
                                            .titleMedium
                                )

                                Text(
                                    "Date: ${entity.date}"
                                )

                                Text(
                                    "Customer: ${entity.customer}"
                                )

                                Text(
                                    "Location: ${entity.location}"
                                )

                                Spacer(
                                    Modifier.height(6.dp)
                                )

                                Button(

                                    onClick = {

                                        try {

                                            val draft =
                                                Json.decodeFromString<QuotationDraft>(
                                                    entity.json
                                                )

                                            onOpen(
                                                draft
                                            )

                                        } catch (_: Exception) {
                                        }
                                    },

                                    modifier =
                                        Modifier.fillMaxWidth()
                                ) {

                                    Text(
                                        "Open Quotation"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}