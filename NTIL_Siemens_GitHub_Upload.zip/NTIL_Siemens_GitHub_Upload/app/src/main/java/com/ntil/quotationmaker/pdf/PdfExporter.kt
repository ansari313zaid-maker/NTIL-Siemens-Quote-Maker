package com.ntil.quotationmaker.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.ntil.quotationmaker.R
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale
import kotlin.math.round

object PdfExporter {

    private val nf = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
        currency = Currency.getInstance("INR")
        maximumFractionDigits = 2
    }

    private fun money(value: Double): String {
        return nf.format(value)
    }

    fun create(context: Context, q: QuotationDraft): File {

        val dir = File(context.cacheDir, "exports").apply {
            mkdirs()
        }

        val safeName = q.quotationNo
            .ifBlank { "quotation" }
            .replace("/", "_")

        val file = File(dir, "$safeName.pdf")

        val document = PdfDocument()

        val pageInfo = PdfDocument.PageInfo
            .Builder(595, 842, 1)
            .create()

        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // ---------------------------------------------------------
        // LOGO
        // ---------------------------------------------------------

        val logoBitmap = BitmapFactory.decodeResource(
            context.resources,
            R.drawable.ntil_logo
        )

        if (logoBitmap != null) {
            val logoRect = RectF(25f, 18f, 170f, 78f)
            canvas.drawBitmap(logoBitmap, null, logoRect, paint)
        }

        // ---------------------------------------------------------
        // COMPANY DETAILS
        // ---------------------------------------------------------

        paint.color = Color.DKGRAY
        paint.textSize = 9f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "Network Techlab India Limited",
            390f,
            26f,
            paint
        )

        canvas.drawText(
            "Plot No. 142, Rd Number 23, MIDC,",
            390f,
            38f,
            paint
        )

        canvas.drawText(
            "Wagle Industrial Estate, Thane West,",
            390f,
            50f,
            paint
        )

        canvas.drawText(
            "Thane, Maharashtra 400604",
            390f,
            62f,
            paint
        )

        canvas.drawText(
            "Email: zaid@netlabindia.com",
            390f,
            74f,
            paint
        )

        canvas.drawText(
            "Phone: 7843852347",
            390f,
            86f,
            paint
        )

        // ---------------------------------------------------------
        // HEADER LINE
        // ---------------------------------------------------------

        paint.color = Color.rgb(20, 96, 150)
        paint.strokeWidth = 3f

        canvas.drawLine(
            24f,
            90f,
            571f,
            90f,
            paint
        )

        // ---------------------------------------------------------
        // QUOTATION TITLE
        // ---------------------------------------------------------

        paint.color = Color.rgb(20, 96, 150)
        paint.textSize = 22f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "QUOTATION",
            218f,
            120f,
            paint
        )

        // ---------------------------------------------------------
        // QUOTATION + CUSTOMER DETAILS
        // ---------------------------------------------------------

        paint.color = Color.DKGRAY
        paint.textSize = 9f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "Quotation No.: ${q.quotationNo}",
            28f,
            145f,
            paint
        )

        canvas.drawText(
            "Date: ${q.date}",
            28f,
            158f,
            paint
        )

        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "TO",
            300f,
            145f,
            paint
        )

        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            q.customer,
            300f,
            158f,
            paint
        )

        canvas.drawText(
            "Location: ${q.location}",
            300f,
            171f,
            paint
        )

        canvas.drawText(
            "Contact Person: ${q.contactPerson}",
            300f,
            184f,
            paint
        )

        canvas.drawText(
            "Phone: ${q.phone}",
            300f,
            197f,
            paint
        )

        canvas.drawText(
            "Email: ${q.email}",
            300f,
            210f,
            paint
        )

        // ---------------------------------------------------------
        // BOQ
        // ---------------------------------------------------------

        var y = 235f

        paint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            paint
        )

        paint.color = Color.WHITE
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "BOQ / Price Schedule",
            30f,
            y,
            paint
        )

        y += 24f

        paint.color = Color.DKGRAY
        paint.textSize = 8f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText("Sr.", 28f, y, paint)
        canvas.drawText("Description / Part No.", 55f, y, paint)
        canvas.drawText("Qty.", 275f, y, paint)
        canvas.drawText("Unit", 315f, y, paint)
        canvas.drawText("LP/MRP", 355f, y, paint)
        canvas.drawText("Sale Disc.%", 405f, y, paint)
        canvas.drawText("Net Rate", 460f, y, paint)
        canvas.drawText("Total", 520f, y, paint)

        y += 17f

        paint.typeface = Typeface.DEFAULT

        q.items.forEach { item ->

            paint.color = Color.DKGRAY
            paint.textSize = 7.5f

            canvas.drawText(
                item.srNo,
                30f,
                y,
                paint
            )

            val description = if (item.description.isNotBlank()) {
                item.description
            } else {
                item.productCode
            }

            canvas.drawText(
                description.take(35),
                55f,
                y,
                paint
            )

            canvas.drawText(
                String.format(Locale.US, "%.2f", item.qty),
                275f,
                y,
                paint
            )

            canvas.drawText(
                item.unit,
                315f,
                y,
                paint
            )

            canvas.drawText(
                money(item.officialPrice),
                355f,
                y,
                paint
            )

            canvas.drawText(
                String.format(
                    Locale.US,
                    "%.2f",
                    item.saleDiscount
                ),
                415f,
                y,
                paint
            )

            canvas.drawText(
                money(item.sellingRate),
                460f,
                y,
                paint
            )

            canvas.drawText(
                money(item.sellingAmount),
                515f,
                y,
                paint
            )

            y += 16f
        }

        // ---------------------------------------------------------
        // BASIC VALUE
        // ---------------------------------------------------------

        val basicValue = q.items.sumOf {
            it.sellingAmount
        }

        y += 5f

        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 9f

        canvas.drawText(
            "Total Basic Value",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(basicValue),
            500f,
            y,
            paint
        )

        // ---------------------------------------------------------
        // COMMERCIAL TERMS
        // ---------------------------------------------------------

        y += 30f

        paint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            paint
        )

        paint.color = Color.WHITE
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "Commercial Terms",
            30f,
            y,
            paint
        )

        y += 22f

        paint.color = Color.DKGRAY
        paint.textSize = 9f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "Payment Terms",
            28f,
            y,
            paint
        )

        canvas.drawText(
            q.paymentTerms,
            180f,
            y,
            paint
        )

        y += 15f

        canvas.drawText(
            "GST",
            28f,
            y,
            paint
        )

        canvas.drawText(
            "${q.gstPercent}%",
            180f,
            y,
            paint
        )

        y += 15f

        canvas.drawText(
            "Freight Charges",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(q.freightCharges),
            180f,
            y,
            paint
        )

        y += 15f

        canvas.drawText(
            "Stock Status",
            28f,
            y,
            paint
        )

        canvas.drawText(
            q.stockStatus,
            180f,
            y,
            paint
        )

        // ---------------------------------------------------------
        // TAX & GRAND TOTAL
        // ---------------------------------------------------------

        y += 28f

        paint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            paint
        )

        paint.color = Color.WHITE
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "Tax & Grand Total",
            30f,
            y,
            paint
        )

        val taxableValue =
            basicValue + q.freightCharges

        val gstAmount =
            taxableValue * q.gstPercent / 100.0

        val grandTotal =
            taxableValue + gstAmount

        y += 24f

        paint.color = Color.DKGRAY
        paint.textSize = 9f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "Basic Quotation Value",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(basicValue),
            500f,
            y,
            paint
        )

        y += 15f

        canvas.drawText(
            "Freight Charges",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(q.freightCharges),
            500f,
            y,
            paint
        )

        y += 15f

        canvas.drawText(
            "Taxable Value",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(taxableValue),
            500f,
            y,
            paint
        )

        y += 15f

        canvas.drawText(
            "GST @ ${q.gstPercent}%",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(gstAmount),
            500f,
            y,
            paint
        )

        y += 18f

        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "GRAND TOTAL",
            28f,
            y,
            paint
        )

        canvas.drawText(
            money(grandTotal),
            500f,
            y,
            paint
        )

        y += 16f

        paint.textSize = 8f

        canvas.drawText(
            "Rounded Off: ${money(round(grandTotal))}/-",
            28f,
            y,
            paint
        )

        // ---------------------------------------------------------
        // BANK DETAILS
        // ---------------------------------------------------------

        y += 25f

        paint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            paint
        )

        paint.color = Color.WHITE
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "Bank Details",
            30f,
            y,
            paint
        )

        y += 20f

        paint.color = Color.DKGRAY
        paint.textSize = 7.5f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "Bank: ICICI Bank Ltd.",
            28f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "Branch: Shop No 9 Ground Floor, Jinja Co-Op Society, Opp. Damani Estate, Naupada, Teenhathnaka-400604",
            28f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "Branch Name: Thane-Teen Hath Naka Branch",
            28f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "Account Number: 100051000002",
            28f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "IFSC Code: ICIC00001000",
            28f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "SWIFT CODE: ICICINBBCTS",
            28f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "Nature of Account: Current Account",
            28f,
            y,
            paint
        )

        // ---------------------------------------------------------
        // ADDITIONAL TERMS
        // ---------------------------------------------------------

        y += 20f

        paint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            paint
        )

        paint.color = Color.WHITE
        paint.textSize = 11f
        paint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "Additional Terms",
            30f,
            y,
            paint
        )

        y += 20f

        paint.color = Color.DKGRAY
        paint.textSize = 7.5f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "1. Order should be placed on the name of Network Techlab India Ltd.",
            30f,
            y,
            paint
        )

        y += 12f

        canvas.drawText(
            "2. Any Varai / Mathadi / Labour Union charges for unloading or loading the material would be extra.",
            30f,
            y,
            paint
        )

        // ---------------------------------------------------------
        // SIGNATURE
        // ---------------------------------------------------------

        y += 25f

        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 9f

        canvas.drawText(
            "For Network Techlab India Limited",
            390f,
            y,
            paint
        )

        y += 25f

        paint.textSize = 16f

        canvas.drawText(
            "Zaid",
            430f,
            y,
            paint
        )

        y += 13f

        paint.textSize = 8f
        paint.typeface = Typeface.DEFAULT

        canvas.drawText(
            "Sr. Engineer Presales",
            405f,
            y,
            paint
        )

        y += 11f

        canvas.drawText(
            "Date: ${q.date}",
            405f,
            y,
            paint
        )

        // ---------------------------------------------------------
        // FINISH
        // ---------------------------------------------------------

        document.finishPage(page)

        FileOutputStream(file).use {
            document.writeTo(it)
        }

        document.close()

        return file
    }
}