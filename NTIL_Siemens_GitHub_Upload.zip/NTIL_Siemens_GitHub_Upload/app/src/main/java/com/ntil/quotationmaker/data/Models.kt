package com.ntil.quotationmaker.data

import kotlinx.serialization.Serializable

@Serializable
data class QuotationDraft(
    val quotationNo: String = "",
    val date: String = "",
    val customer: String = "",
    val location: String = "",
    val contactPerson: String = "",
    val phone: String = "",
    val email: String = "",

    val paymentTerms: String = "120 days",
    val gstPercent: Double = 18.0,
    val freightCharges: Double = 0.0,
    val stockStatus: String = "",

    val showLpDiscount: Boolean = true,
    val items: List<BoqItem> = listOf(
        BoqItem(srNo = "1")
    )
)

@Serializable
data class BoqItem(
    val srNo: String = "",
    val productCode: String = "",
    val description: String = "",
    val qty: Double = 0.0,
    val unit: String = "Nos",
    val officialPrice: Double = 0.0,
    val priceLabel: String = "LP/MRP",
    val purchaseDiscount: Double = 0.0,
    val saleDiscount: Double = 0.0
) {
    val purchaseRate: Double
        get() = officialPrice * (1.0 - purchaseDiscount / 100.0)

    val sellingRate: Double
        get() = officialPrice * (1.0 - saleDiscount / 100.0)

    val purchaseAmount: Double
        get() = purchaseRate * qty

    val sellingAmount: Double
        get() = sellingRate * qty

    val margin: Double
        get() = sellingAmount - purchaseAmount

    val marginPercent: Double
        get() = if (purchaseAmount != 0.0) {
            margin / purchaseAmount * 100.0
        } else {
            0.0
        }
}

@Serializable
data class SiemensProduct(
    val code: String,
    val price: Double,
    val priceLabel: String,
    val page: Int
)