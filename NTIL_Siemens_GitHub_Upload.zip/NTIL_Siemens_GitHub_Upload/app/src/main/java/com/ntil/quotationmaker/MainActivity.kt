package com.ntil.quotationmaker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.ntil.quotationmaker.data.*
import com.ntil.quotationmaker.excel.ExcelExporter
import com.ntil.quotationmaker.pdf.PdfExporter
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            App()
        }
    }

    @Composable
    private fun App() {

        val db = remember { QuotationDatabase.get(this) }
        val priceRepo = remember { SiemensPriceRepository.get(this) }
        val scope = rememberCoroutineScope()

        var q by remember {
            mutableStateOf(
                QuotationDraft(
                    quotationNo = "NTIL/2026-27/",
                    paymentTerms = "120 days",
                    gstPercent = 18.0,
                    stockStatus = "Ready Stock"
                )
            )
        }

        var history by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf("") }

        fun share(file: File, mime: String) {
            val uri = FileProvider.getUriForFile(
                this,
                "com.ntil.quotationmaker.fileprovider",
                file
            )

            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Share quotation"
                )
            )
        }

        MaterialTheme {

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text("NTIL Quotation Master")
                        },
                        actions = {
                            TextButton(
                                onClick = {
                                    history = !history
                                    message = ""
                                }
                            ) {
                                Text(
                                    if (history) "New" else "History"
                                )
                            }
                        }
                    )
                }
            ) { pad ->

                if (history) {

                    History(db) {
                        q = it
                        history = false
                    }

                } else {

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(pad)
                            .padding(12.dp)
                    ) {

                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {

                            item {

                                Text(
                                    "Quotation Details",
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Spacer(Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = q.quotationNo,
                                    onValueChange = {
                                        q = q.copy(quotationNo = it)
                                    },
                                    label = {
                                        Text("Quotation No.")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.date,
                                    onValueChange = {
                                        q = q.copy(date = it)
                                    },
                                    label = {
                                        Text("Date")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                Text(
                                    "Customer Details",
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.customer,
                                    onValueChange = {
                                        q = q.copy(customer = it)
                                    },
                                    label = {
                                        Text("Customer Name")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.location,
                                    onValueChange = {
                                        q = q.copy(location = it)
                                    },
                                    label = {
                                        Text("Location")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.contactPerson,
                                    onValueChange = {
                                        q = q.copy(contactPerson = it)
                                    },
                                    label = {
                                        Text("Contact Person")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.phone,
                                    onValueChange = {
                                        q = q.copy(phone = it)
                                    },
                                    label = {
                                        Text("Phone No.")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.email,
                                    onValueChange = {
                                        q = q.copy(email = it)
                                    },
                                    label = {
                                        Text("Email ID")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(12.dp))

                                Text(
                                    "Commercial Terms",
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.paymentTerms,
                                    onValueChange = {
                                        q = q.copy(paymentTerms = it)
                                    },
                                    label = {
                                        Text("Payment Terms")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.gstPercent.toString(),
                                    onValueChange = {
                                        q = q.copy(
                                            gstPercent =
                                                it.toDoubleOrNull() ?: 0.0
                                        )
                                    },
                                    label = {
                                        Text("GST %")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.freightCharges.toString(),
                                    onValueChange = {
                                        q = q.copy(
                                            freightCharges =
                                                it.toDoubleOrNull() ?: 0.0
                                        )
                                    },
                                    label = {
                                        Text("Freight Charges")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = q.stockStatus,
                                    onValueChange = {
                                        q = q.copy(stockStatus = it)
                                    },
                                    label = {
                                        Text("Stock Status")
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {

                                    Checkbox(
                                        checked = q.showLpDiscount,
                                        onCheckedChange = {
                                            q = q.copy(
                                                showLpDiscount = it
                                            )
                                        }
                                    )

                                    Text(
                                        "Show LP/MRP & discount on customer quotation"
                                    )
                                }

                                Spacer(Modifier.height(12.dp))

                                Text(
                                    "BOQ",
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Text(
                                    "Search Siemens product code; official LP/MRP will fill automatically.",
                                    style = MaterialTheme.typography.bodySmall
                                )

                                Spacer(Modifier.height(6.dp))
                            }

                            itemsIndexed(
                                q.items,
                                key = { index, _ -> index }
                            ) { i, item ->

                                BoqRow(
                                    item = item,
                                    repo = priceRepo,

                                    onChange = { newItem ->
                                        q = q.copy(
                                            items = q.items
                                                .toMutableList()
                                                .also {
                                                    it[i] = newItem
                                                }
                                        )
                                    },

                                    add = {
                                        q = q.copy(
                                            items = q.items +
                                                    BoqItem(
                                                        srNo =
                                                            (q.items.size + 1)
                                                                .toString()
                                                    )
                                        )
                                    },

                                    del = {
                                        if (q.items.size > 1) {
                                            q = q.copy(
                                                items = q.items
                                                    .filterIndexed {
                                                            index, _ ->
                                                        index != i
                                                    }
                                            )
                                        }
                                    }
                                )
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement =
                                Arrangement.spacedBy(6.dp)
                        ) {

                            Button(
                                onClick = {

                                    scope.launch {

                                        db.quotationDao().upsert(
                                            QuotationEntity(
                                                q.quotationNo,
                                                q.date,
                                                q.customer,
                                                q.location,
                                                Json.encodeToString(q)
                                            )
                                        )

                                        message = "Quotation Saved"
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Save")
                            }

                            Button(
                                onClick = {

                                    runCatching {

                                        share(
                                            PdfExporter.create(
                                                this@MainActivity,
                                                q
                                            ),
                                            "application/pdf"
                                        )

                                    }.onFailure {

                                        message =
                                            it.message ?: "PDF Error"
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("PDF")
                            }

                            Button(
                                onClick = {

                                    runCatching {

                                        share(
                                            ExcelExporter.create(
                                                this@MainActivity,
                                                q
                                            ),
                                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                        )

                                    }.onFailure {

                                        message =
                                            it.message ?: "Excel Error"
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Excel")
                            }
                        }

                        if (message.isNotBlank()) {

                            Text(
                                text = message,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun BoqRow(
        item: BoqItem,
        repo: SiemensPriceRepository,
        onChange: (BoqItem) -> Unit,
        add: () -> Unit,
        del: () -> Unit
    ) {

        var query by remember(
            item.srNo,
            item.productCode
        ) {
            mutableStateOf(item.productCode)
        }

        var suggestions by remember {
            mutableStateOf(
                emptyList<SiemensProduct>()
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {

            Column(
                modifier = Modifier.padding(8.dp)
            ) {

                Row(
                    horizontalArrangement =
                        Arrangement.spacedBy(6.dp)
                ) {

                    OutlinedTextField(
                        value = item.srNo,
                        onValueChange = {
                            onChange(
                                item.copy(srNo = it)
                            )
                        },
                        label = {
                            Text("Sr")
                        },
                        modifier = Modifier.width(68.dp)
                    )

                    OutlinedTextField(
                        value = query,
                        onValueChange = {

                            query = it

                            suggestions =
                                if (it.length >= 2) {
                                    repo.search(it)
                                } else {
                                    emptyList()
                                }

         