package com.ntil.quotationmaker.data

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

/** Offline product master seeded from Siemens Limited Price List w.e.f. 01.07.2026. */
data class SiemensProduct(
    val code: String,
    val price: Double,
    val priceLabel: String,
    val page: Int
) {
    val normalized: String get() = code.uppercase(Locale.US).filter { it.isLetterOrDigit() }
}

class SiemensPriceRepository private constructor(private val products: List<SiemensProduct>) {
    fun search(query: String, limit: Int = 12): List<SiemensProduct> {
        val q = query.uppercase(Locale.US).trim()
        if (q.isBlank()) return emptyList()
        val n = q.filter { it.isLetterOrDigit() }
        return products.asSequence()
            .filter { it.code.uppercase(Locale.US).contains(q) || it.normalized.contains(n) }
            .sortedWith(compareBy<SiemensProduct> { if (it.code.equals(q, true)) 0 else if (it.normalized == n) 1 else 2 }.thenBy { it.code })
            .take(limit)
            .toList()
    }

    fun exactOrNormalized(query: String): SiemensProduct? {
        val q = query.uppercase(Locale.US).trim()
        val n = q.filter { it.isLetterOrDigit() }
        return products.firstOrNull { it.code.equals(q, true) }
            ?: products.firstOrNull { it.normalized == n }
    }

    companion object {
        @Volatile private var INSTANCE: SiemensPriceRepository? = null
        fun get(context: Context): SiemensPriceRepository = INSTANCE ?: synchronized(this) {
            INSTANCE ?: load(context).also { INSTANCE = it }
        }
        private fun load(context: Context): SiemensPriceRepository {
            val list = mutableListOf<SiemensProduct>()
            context.assets.open("siemens_price_2026_07.tsv").use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).useLines { lines ->
                    lines.drop(1).forEach { line ->
                        val p = line.split('\t')
                        if (p.size >= 4) list += SiemensProduct(p[0], p[1].toDoubleOrNull() ?: 0.0, p[2], p[3].toIntOrNull() ?: 0)
                    }
                }
            }
            return SiemensPriceRepository(list)
        }
    }
}
