package com.ntil.quotationmaker.excel

import android.content.Context
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.round

object ExcelExporter {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun sheetXml(rows: List<List<String>>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { r, row ->
            append("<row r=\"${r + 1}\">")
            row.forEachIndexed { c, v ->
                val col = (c + 1).toString()
                append("<c r=\"$col${r + 1}\" t=\"inlineStr\"><is><t>${esc(v)}</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    fun create(context: Context, q: QuotationDraft): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "${q.quotationNo.replace('/', '_')}.xlsx")
        val basic = q.items.sumOf { it.total }
        val taxable = basic + q.freight
        val gst = taxable * q.gstPercent / 100.0
        val grand = taxable + gst

        val common = mutableListOf<List<String>>()
        common += listOf("QUOTATION", q.quotationNo)
        common += listOf("Date", q.date)
        common += listOf("Customer", q.customer)
        common += listOf("Location", q.location)
        common += listOf("")

        val working = common.toMutableList()
        working += listOf("Sr. No.", "Product Code", "Description", "Qty", "Unit", "Official LP/MRP", "Purchase Disc %", "Sale Disc %", "Purchase Rate", "Sale Rate", "Purchase Value", "Selling Value", "Margin", "Margin %")
        q.items.forEach { i ->
            working += listOf(i.srNo, i.productCode, i.description, i.qty.toString(), i.unit, i.officialPrice.toString(), i.purchaseDiscount.toString(), i.saleDiscount.toString(), i.purchaseRate.toString(), i.sellingRate.toString(), i.purchaseValue.toString(), i.total.toString(), i.margin.toString(), i.marginPercent.toString())
        }
        working += listOf("")
        working += listOf("Basic Quotation Value", basic.toString())
        working += listOf("Freight Charges", q.freight.toString())
        working += listOf("Taxable Value", taxable.toString())
        working += listOf("GST", gst.toString())
        working += listOf("Grand Total", grand.toString())
        working += listOf("Rounded Off", round(grand).toString())

        val customer = common.toMutableList()
        customer += if (q.showLpDiscount) listOf("Sr. No.", "Product Code", "Description", "Qty", "Unit", "LP/MRP", "Sale Discount %", "Sale Rate", "Total Amount")
        else listOf("Sr. No.", "Product Code", "Description", "Qty", "Unit", "Sale Rate", "Total Amount")
        q.items.forEach { i ->
            customer += if (q.showLpDiscount) listOf(i.srNo, i.productCode, i.description, i.qty.toString(), i.unit, i.officialPrice.toString(), i.saleDiscount.toString(), i.sellingRate.toString(), i.total.toString())
            else listOf(i.srNo, i.productCode, i.description, i.qty.toString(), i.unit, i.sellingRate.toString(), i.total.toString())
        }
        customer += listOf("")
        customer += listOf("Basic Quotation Value", basic.toString())
        customer += listOf("Freight Charges", q.freight.toString())
        customer += listOf("Taxable Value", taxable.toString())
        customer += listOf("GST @ ${q.gstPercent}%", gst.toString())
        customer += listOf("Grand Total", grand.toString())
        customer += listOf("Rounded Off", round(grand).toString())

        ZipOutputStream(f.outputStream()).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray()); z.closeEntry()
            }
            put("[Content_Types].xml", "<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>")
            put("_rels/.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            put("xl/workbook.xml", "<?xml version=\"1.0\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Working\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"Customer\" sheetId=\"2\" r:id=\"rId2\"/></sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/></Relationships>")
            put("xl/worksheets/sheet1.xml", sheetXml(working))
            put("xl/worksheets/sheet2.xml", sheetXml(customer))
        }
        return f
    }
}
