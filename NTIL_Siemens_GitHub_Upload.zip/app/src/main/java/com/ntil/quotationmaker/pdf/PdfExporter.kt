package com.ntil.quotationmaker.pdf

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.*

object PdfExporter {
    private val nf = NumberFormat.getCurrencyInstance(Locale("en","IN")).apply { currency = Currency.getInstance("INR") }
    private fun money(v: Double) = nf.format(v).replace("₹", "₹")
    fun create(context: Context, q: QuotationDraft): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "${q.quotationNo.replace('/','_')}.pdf")
        val doc = PdfDocument(); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans", Typeface.NORMAL)
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); val c=page.canvas
        p.color=Color.rgb(20,96,150); p.strokeWidth=3f; c.drawLine(24f,82f,571f,82f,p)
        p.color=Color.rgb(20,96,150); p.textSize=22f; p.typeface=Typeface.DEFAULT_BOLD; c.drawText("QUOTATION",218f,112f,p)
        p.color=Color.DKGRAY; p.textSize=9f; p.typeface=Typeface.DEFAULT
        c.drawText("Network Techlab India Limited",390f,26f,p); c.drawText("Plot No. 142, Rd Number 23, MIDC,",390f,38f,p); c.drawText("Wagle Industrial Estate, Thane West,",390f,50f,p); c.drawText("Thane, Maharashtra 400604",390f,62f,p); c.drawText("Email: zaid@netlabindia.com",390f,74f,p); c.drawText("Phone: 7843852347",390f,86f,p)
        p.textSize=10f; c.drawText("Quotation No.: ${q.quotationNo}",28f,140f,p); c.drawText("Date: ${q.date}",28f,153f,p); c.drawText("TO",300f,140f,p); c.drawText(q.customer,300f,153f,p); c.drawText("Location: ${q.location}",300f,166f,p)
        var y=195f
        p.color=Color.rgb(20,96,150); c.drawRect(24f,y-17,571f,y+4,p); p.color=Color.WHITE; p.textSize=11f; p.typeface=Typeface.DEFAULT_BOLD; c.drawText("BOQ / Price Schedule",30f,y,p)
        y+=24; p.color=Color.DKGRAY; p.textSize=8f; c.drawText("Sr. No.",28f,y,p); c.drawText("Description / Part No.",78f,y,p); c.drawText("Qty.",285f,y,p); c.drawText("Unit",330f,y,p); var x=370f; if(q.showLpDiscount){c.drawText("Official (₹)",370f,y,p); c.drawText("Sale Disc.%",430f,y,p); c.drawText("Net Rate (₹)",475f,y,p); x=540f}else{c.drawText("Unit Rate (₹)",370f,y,p); x=475f}; c.drawText("Total (₹)",500f,y,p)
        p.typeface=Typeface.DEFAULT; y+=17
        q.items.forEach { item -> p.color=Color.DKGRAY; c.drawText(item.srNo,30f,y,p); c.drawText(item.description.take(28),78f,y,p); c.drawText("${item.qty}",285f,y,p); c.drawText(item.unit,330f,y,p); if(q.showLpDiscount){c.drawText(money(item.officialPrice),370f,y,p); c.drawText(String.format("%.2f",item.saleDiscount),430f,y,p); c.drawText(money(item.sellingRate),475f,y,p)}else c.drawText(money(item.sellingRate),370f,y,p); c.drawText(money(item.total),500f,y,p); y+=16 }
        val basic=q.items.sumOf{it.total}; p.typeface=Typeface.DEFAULT_BOLD; c.drawText("Total Basic Value",28f,y,p); c.drawText(money(basic),500f,y,p); y+=35
        p.color=Color.rgb(20,96,150); c.drawRect(24f,y-17,571f,y+4,p); p.color=Color.WHITE; c.drawText("Commercial Terms",30f,y,p); y+=22; p.color=Color.DKGRAY; p.typeface=Typeface.DEFAULT; c.drawText("Payment Terms",28f,y,p); c.drawText(q.paymentTerms,180f,y,p); y+=15; c.drawText("GST",28f,y,p); c.drawText("${q.gstPercent}%",180f,y,p); y+=15; c.drawText("Freight Charges",28f,y,p); c.drawText(money(q.freight),180f,y,p); y+=15; c.drawText("Stock",28f,y,p); c.drawText(q.stock,180f,y,p); y+=15; c.drawText("Delivery",28f,y,p); c.drawText(q.delivery,180f,y,p)
        y+=28; p.color=Color.rgb(20,96,150); c.drawRect(24f,y-17,571f,y+4,p); p.color=Color.WHITE; p.typeface=Typeface.DEFAULT_BOLD; c.drawText("Tax & Grand Total",30f,y,p); y+=24; p.color=Color.DKGRAY; p.typeface=Typeface.DEFAULT; val taxable=basic+q.freight; val gst=taxable*q.gstPercent/100; c.drawText("Basic Quotation Value",28f,y,p); c.drawText(money(basic),500f,y,p); y+=15; c.drawText("Freight Charges",28f,y,p); c.drawText(money(q.freight),500f,y,p); y+=15; c.drawText("Taxable Value",28f,y,p); c.drawText(money(taxable),500f,y,p); y+=15; c.drawText("GST @ ${q.gstPercent}%",28f,y,p); c.drawText(money(gst),500f,y,p); y+=18; p.typeface=Typeface.DEFAULT_BOLD; c.drawText("GRAND TOTAL",28f,y,p); c.drawText(money(taxable+gst),500f,y,p); y+=18; c.drawText("Rounded Off: ${money(kotlin.math.round(taxable+gst))}/-",28f,y,p); y+=24; p.typeface=Typeface.DEFAULT; c.drawText("Terms & Conditions",28f,y,p); y+=15; q.terms.take(9).forEachIndexed{idx,t->c.drawText("${idx+1}. $t",30f,y,p); y+=12}
        y+=18; p.typeface=Typeface.DEFAULT_BOLD; c.drawText("For Network Techlab India Limited",190f,y,p); y+=25; p.textSize=18f; c.drawText("Zaid",220f,y,p); p.textSize=9f; y+=15; p.typeface=Typeface.DEFAULT; c.drawText("Sr. Engineer Presales",220f,y,p); y+=12; c.drawText("Date: ${q.date}",220f,y,p)
        doc.finishPage(page); FileOutputStream(file).use{doc.writeTo(it)}; doc.close(); return file
    }
}
