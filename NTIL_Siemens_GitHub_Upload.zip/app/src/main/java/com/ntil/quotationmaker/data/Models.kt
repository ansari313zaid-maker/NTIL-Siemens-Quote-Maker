package com.ntil.quotationmaker.data

import kotlinx.serialization.Serializable

@Serializable
data class BoqItem(
    val srNo: String = "1",
    val productCode: String = "",
    val description: String = "",
    val qty: Double = 1.0,
    val unit: String = "Nos",
    val officialPrice: Double = 0.0,
    val priceLabel: String = "LP",
    val purchaseDiscount: Double = 0.0,
    val saleDiscount: Double = 0.0
) {
    val purchaseRate get() = officialPrice * (1.0 - purchaseDiscount / 100.0)
    val sellingRate get() = officialPrice * (1.0 - saleDiscount / 100.0)
    val purchaseValue get() = qty * purchaseRate
    val total get() = qty * sellingRate
    val margin get() = total - purchaseValue
    val marginPercent get() = if (total == 0.0) 0.0 else margin / total * 100.0
}

@Serializable
data class QuotationDraft(
    val quotationNo: String = "NTIL/2026-27/",
    val date: String = "14 September 2026",
    val customer: String = "",
    val location: String = "",
    val paymentTerms: String = "120 days",
    val gstPercent: Double = 18.0,
    val freight: Double = 0.0,
    val stock: String = "Ready stock",
    val delivery: String = "Within one week",
    val currency: String = "INR",
    val showLpDiscount: Boolean = false,
    val terms: List<String> = listOf(
        "Prices are in INR.", "GST is charged at 18%.",
        "Freight charges are subject to 18% GST.", "Payment is due within the agreed credit period.",
        "Material is available in ready stock.", "Delivery is within one week, subject to mutual agreement.",
        "Quotation validity is 15 days from quotation date.", "Statutory tax or duty changes apply as actuals.",
        "Supply will match the stated specifications and part numbers."
    ),
    val items: List<BoqItem> = listOf(BoqItem())
)
