package com.ntil.quotationmaker.pdf

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.ntil.quotationmaker.R
import com.ntil.quotationmaker.data.QuotationDraft
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale
import kotlin.math.round

object PdfExporter {

    private val nf =
        NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
            currency = Currency.getInstance("INR")
            maximumFractionDigits = 2
            minimumFractionDigits = 2
        }

    private fun money(value: Double): String {
        return nf.format(value)
    }

    fun create(
        context: Context,
        q: QuotationDraft
    ): File {

        val dir = File(context.cacheDir, "exports").apply {
            mkdirs()
        }

        val safeQuotationNo =
            q.quotationNo
                .ifBlank { "Quotation" }
                .replace("/", "_")
                .replace("\\", "_")

        val file = File(
            dir,
            "$safeQuotationNo.pdf"
        )

        val document = PdfDocument()

        val pageInfo =
            PdfDocument.PageInfo.Builder(
                595,
                842,
                1
            ).create()

        val page =
            document.startPage(pageInfo)

        val canvas = page.canvas

        val normalPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 9f
                typeface = Typeface.DEFAULT
            }

        val boldPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
            }

        val bluePaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(20, 96, 150)
            }

        val whiteBoldPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
            }

        // ---------------------------------------------------------
        // HEADER / LOGO
        // ---------------------------------------------------------

        val logo =
            BitmapFactory.decodeResource(
                context.resources,
                R.drawable.ntil_logo
            )

        if (logo != null) {

            val maxWidth = 150f
            val maxHeight = 60f

            val scale =
                minOf(
                    maxWidth / logo.width,
                    maxHeight / logo.height
                )

            val logoWidth =
                logo.width * scale

            val logoHeight =
                logo.height * scale

            val left =
                28f

            val top =
                18f

            canvas.drawBitmap(
                logo,
                null,
                android.graphics.RectF(
                    left,
                    top,
                    left + logoWidth,
                    top + logoHeight
                ),
                normalPaint
            )
        }

        normalPaint.textSize = 9f

        canvas.drawText(
            "Network Techlab India Limited",
            390f,
            26f,
            normalPaint
        )

        canvas.drawText(
            "Plot No. 142, Rd Number 23, MIDC,",
            390f,
            38f,
            normalPaint
        )

        canvas.drawText(
            "Wagle Industrial Estate, Thane West,",
            390f,
            50f,
            normalPaint
        )

        canvas.drawText(
            "Thane, Maharashtra 400604",
            390f,
            62f,
            normalPaint
        )

        canvas.drawText(
            "Email: zaid@netlabindia.com",
            390f,
            74f,
            normalPaint
        )

        canvas.drawText(
            "Phone: 7843852347",
            390f,
            86f,
            normalPaint
        )

        // Blue separator
        bluePaint.strokeWidth = 3f

        canvas.drawLine(
            24f,
            96f,
            571f,
            96f,
            bluePaint
        )

        // QUOTATION title
        bluePaint.color = Color.rgb(20, 96, 150)
        bluePaint.textSize = 22f
        bluePaint.typeface = Typeface.DEFAULT_BOLD

        canvas.drawText(
            "QUOTATION",
            218f,
            125f,
            bluePaint
        )

        // ---------------------------------------------------------
        // QUOTATION + CUSTOMER DETAILS
        // ---------------------------------------------------------

        normalPaint.textSize = 9f

        canvas.drawText(
            "Quotation No.: ${q.quotationNo}",
            28f,
            150f,
            normalPaint
        )

        canvas.drawText(
            "Date: ${q.date}",
            28f,
            164f,
            normalPaint
        )

        boldPaint.textSize = 9f

        canvas.drawText(
            "TO",
            300f,
            150f,
            boldPaint
        )

        canvas.drawText(
            q.customer.ifBlank { "-" },
            300f,
            164f,
            normalPaint
        )

        canvas.drawText(
            "Location: ${q.location.ifBlank { "-" }}",
            300f,
            178f,
            normalPaint
        )

        canvas.drawText(
            "Contact Person: ${q.contactPerson.ifBlank { "-" }}",
            300f,
            192f,
            normalPaint
        )

        canvas.drawText(
            "Phone: ${q.phone.ifBlank { "-" }}",
            300f,
            206f,
            normalPaint
        )

        canvas.drawText(
            "Email: ${q.email.ifBlank { "-" }}",
            300f,
            220f,
            normalPaint
        )

        // ---------------------------------------------------------
        // BOQ
        // ---------------------------------------------------------

        var y = 242f

        bluePaint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            bluePaint
        )

        canvas.drawText(
            "BOQ / PRICE SCHEDULE",
            30f,
            y,
            whiteBoldPaint
        )

        y += 24f

        normalPaint.textSize = 7.5f

        canvas.drawText(
            "Sr.",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            "Description / Part No.",
            58f,
            y,
            boldPaint
        )

        canvas.drawText(
            "Qty.",
            280f,
            y,
            boldPaint
        )

        canvas.drawText(
            "Unit",
            315f,
            y,
            boldPaint
        )

        if (q.showLpDiscount) {

            canvas.drawText(
                "Official ₹",
                350f,
                y,
                boldPaint
            )

            canvas.drawText(
                "Disc %",
                420f,
                y,
                boldPaint
            )

            canvas.drawText(
                "Net Rate ₹",
                462f,
                y,
                boldPaint
            )

            canvas.drawText(
                "Total ₹",
                525f,
                y,
                boldPaint
            )

        } else {

            canvas.drawText(
                "Unit Rate ₹",
                350f,
                y,
                boldPaint
            )

            canvas.drawText(
                "Total ₹",
                525f,
                y,
                boldPaint
            )
        }

        y += 17f

        normalPaint.textSize = 7f

        q.items.forEach { item ->

            canvas.drawText(
                item.srNo,
                30f,
                y,
                normalPaint
            )

            canvas.drawText(
                item.description
                    .ifBlank { item.productCode }
                    .take(32),
                58f,
                y,
                normalPaint
            )

            canvas.drawText(
                String.format("%.2f", item.qty),
                280f,
                y,
                normalPaint
            )

            canvas.drawText(
                item.unit,
                315f,
                y,
                normalPaint
            )

            if (q.showLpDiscount) {

                canvas.drawText(
                    money(item.officialPrice),
                    350f,
                    y,
                    normalPaint
                )

                canvas.drawText(
                    String.format(
                        "%.2f",
                        item.saleDiscount
                    ),
                    420f,
                    y,
                    normalPaint
                )

                canvas.drawText(
                    money(item.sellingRate),
                    462f,
                    y,
                    normalPaint
                )

                canvas.drawText(
                    money(item.sellingAmount),
                    525f,
                    y,
                    normalPaint
                )

            } else {

                canvas.drawText(
                    money(item.sellingRate),
                    350f,
                    y,
                    normalPaint
                )

                canvas.drawText(
                    money(item.sellingAmount),
                    525f,
                    y,
                    normalPaint
                )
            }

            y += 15f
        }

        // ---------------------------------------------------------
        // BASIC TOTAL
        // ---------------------------------------------------------

        val basicValue =
            q.items.sumOf {
                it.sellingAmount
            }

        y += 5f

        boldPaint.textSize = 8.5f

        canvas.drawText(
            "Total Basic Value",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            money(basicValue),
            500f,
            y,
            boldPaint
        )

        // ---------------------------------------------------------
        // COMMERCIAL TERMS
        // ---------------------------------------------------------

        y += 28f

        bluePaint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            bluePaint
        )

        canvas.drawText(
            "COMMERCIAL TERMS",
            30f,
            y,
            whiteBoldPaint
        )

        y += 22f

        normalPaint.textSize = 8.5f

        canvas.drawText(
            "Payment Terms",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            q.paymentTerms.ifBlank { "-" },
            180f,
            y,
            normalPaint
        )

        y += 15f

        canvas.drawText(
            "GST",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            "${q.gstPercent}%",
            180f,
            y,
            normalPaint
        )

        y += 15f

        canvas.drawText(
            "Freight Charges",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            money(q.freightCharges),
            180f,
            y,
            normalPaint
        )

        y += 15f

        canvas.drawText(
            "Stock Status",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            q.stockStatus.ifBlank { "-" },
            180f,
            y,
            normalPaint
        )

        // ---------------------------------------------------------
        // TAX & GRAND TOTAL
        // ---------------------------------------------------------

        y += 28f

        bluePaint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            bluePaint
        )

        canvas.drawText(
            "TAX & GRAND TOTAL",
            30f,
            y,
            whiteBoldPaint
        )

        val taxableValue =
            basicValue + q.freightCharges

        val gstAmount =
            taxableValue *
                    q.gstPercent /
                    100.0

        val grandTotal =
            taxableValue + gstAmount

        y += 22f

        canvas.drawText(
            "Basic Quotation Value",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            money(basicValue),
            500f,
            y,
            normalPaint
        )

        y += 15f

        canvas.drawText(
            "Freight Charges",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            money(q.freightCharges),
            500f,
            y,
            normalPaint
        )

        y += 15f

        canvas.drawText(
            "Taxable Value",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            money(taxableValue),
            500f,
            y,
            normalPaint
        )

        y += 15f

        canvas.drawText(
            "GST @ ${q.gstPercent}%",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            money(gstAmount),
            500f,
            y,
            normalPaint
        )

        y += 18f

        boldPaint.textSize = 10f

        canvas.drawText(
            "GRAND TOTAL",
            28f,
            y,
            boldPaint
        )

        canvas.drawText(
            money(grandTotal),
            500f,
            y,
            boldPaint
        )

        y += 15f

        normalPaint.textSize = 8f

        canvas.drawText(
            "Rounded Off: ${money(round(grandTotal))}/-",
            28f,
            y,
            normalPaint
        )

        // ---------------------------------------------------------
        // BANK DETAILS
        // ---------------------------------------------------------

        y += 25f

        bluePaint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            bluePaint
        )

        canvas.drawText(
            "BANK DETAILS",
            30f,
            y,
            whiteBoldPaint
        )

        y += 20f

        normalPaint.textSize = 7.5f

        canvas.drawText(
            "Bank: ICICI Bank Ltd.",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            "Branch Name: Thane-Teen Hath Naka Branch",
            300f,
            y,
            normalPaint
        )

        y += 12f

        canvas.drawText(
            "Branch: Shop No 9 Ground Floor, Jinja Co-Op Society, Opp. Damani Estate,",
            28f,
            y,
            normalPaint
        )

        y += 12f

        canvas.drawText(
            "Naupada, Teenhathnaka-400604",
            28f,
            y,
            normalPaint
        )

        y += 12f

        canvas.drawText(
            "Account Number: 100051000002",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            "IFSC Code: ICIC00001000",
            300f,
            y,
            normalPaint
        )

        y += 12f

        canvas.drawText(
            "SWIFT CODE: ICICINBBCTS",
            28f,
            y,
            normalPaint
        )

        canvas.drawText(
            "Nature of Account: Current Account",
            300f,
            y,
            normalPaint
        )

        // ---------------------------------------------------------
        // ADDITIONAL TERMS
        // ---------------------------------------------------------

        y += 22f

        bluePaint.color = Color.rgb(20, 96, 150)

        canvas.drawRect(
            24f,
            y - 17f,
            571f,
            y + 4f,
            bluePaint
        )

        canvas.drawText(
            "TERMS & CONDITIONS",
            30f,
            y,
            whiteBoldPaint
        )

        y += 19f

        normalPaint.textSize = 7.5f

        canvas.drawText(
            "1. Order should be placed on the name of Network Techlab India Ltd.",
            30f,
            y,
            normalPaint
        )

        y += 13f

        canvas.drawText(
            "2. Any Varai / Mathadi / Labour Union charges for unloading or loading",
            30f,
            y,
            normalPaint
        )

        y += 11f

        canvas.drawText(
            "   the material would be extra.",
            30f,
            y,
            normalPaint
        )

        // ---------------------------------------------------------
        // SIGNATURE
        // ---------------------------------------------------------

        y += 24f

        boldPaint.textSize = 8.5f

        canvas.drawText(
            "For Network Techlab India Limited",
            380f,
            y,
            boldPaint
        )

        y += 23f

        boldPaint.textSize = 15f

        canvas.drawText(
            "Zaid",
            430f,
            y,
            boldPaint
        )

        y += 13f

        normalPaint.textSize = 7.5f

        canvas.drawText(
            "Sr. Engineer Presales",
            405f,
            y,
            normalPaint
        )

        y += 11f

        canvas.drawText(
            "Date: ${q.date}",
            405f,
            y,
            normalPaint
        )

        // ---------------------------------------------------------
        // FOOTER
        // ---------------------------------------------------------

        bluePaint.color = Color.rgb(20, 96, 150)

        canvas.drawLine(
            24f,
            820f,
            571f,
            820f,
            bluePaint
        )

        normalPaint.textSize = 6.5f

        canvas.drawText(
            "Network Techlab India Limited",
            28f,
            833f,
            normalPaint
        )

        canvas.drawText(
            "Computer generated quotation",
            430f,
            833f,
            normalPaint
        )

        // Finish page
        document.finishPage(page)

        FileOutputStream(file).use {
            document.writeTo(it)
        }

        document.close()

        return file
    }
}